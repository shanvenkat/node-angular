README

1) indiaasset\WEB-INF\classes\config\SampleConfig.properties

   This file used for Database configuration & Mail configuration only..
   
  
2) indiaasset\doc\sql.txt

   This file contains only Database table creation
