
/**
* Owner					    : iGrandee
* @author				    : K.Sivakumar & R.Manoharan
* Date					    : Oct-10-2003
* Description			    : get Hibernate Sessions and may
* Future use				: contains methods to get DBConnections or Transactions for JNDI
* @version				    : 1.0
* --------------------Modification History----------------------------------------
* Modification Number		:
* Date						:
* Modified By				:
* Documented By				: iGrandians
* Description				:
* Version					:
* --------------------Modification History----------------------------------------
*/

package com.hybridshore.asset.common.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;

import java.sql.SQLException;

/**
* This class is use for service Locator
*/

public class ServiceLocator
{
    public static final ThreadLocal session = new ThreadLocal();

    public static ServiceLocator me;
	private static ServletContext  context=null;

    static
	{
        try
		{
          me = new ServiceLocator();
        }
		catch (Exception e)
		{
            System.out.println("Error occurred initializing ServiceLocator");
        }
    }

    public ServiceLocator(ServletContext servletcontext) throws Exception
    {
        context=servletcontext;
	}

    private ServiceLocator() throws Exception
	{
    }


    public static ServletContext getContext()
	{
		return context;
	}

}
//EOF