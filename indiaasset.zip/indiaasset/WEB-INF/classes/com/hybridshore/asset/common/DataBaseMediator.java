// Author Name : Mr.K. Sivakumar & Mr.V.Venkateshan
// Decompiler options: packimports(3)
// Source File Name:   DataBaseMediator.java

package com.hybridshore.asset.common;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.sql.*;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Vector;

// Referenced classes of package com.hybridshore.asset.common:
//            SqlBean

public class DataBaseMediator extends SqlBean
{

    public DataBaseMediator()
    {
        stmt = null;
        rs = null;
        rsmd = null;
        callStmt = null;
        status = 0;
    }

    public long fmaxId(String strQuery)
        throws SQLException
    {
        long l_return_value = 0L;
        ResultSet result = null;
        try
        {
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            result = stmt.executeQuery(strQuery);
            if(result.next())
                l_return_value = result.getLong(1);
            l_return_value++;
        }
        catch(Exception e)
        {
            System.out.println("SQL Exception ::" + e.getMessage());
        }
        finally
        {
            try
            {
                takeDownAsset();
            }
            catch(Exception asset_final_exp) { }
        }
        return l_return_value;
    }

    public int insertUpdateDeleteRecord(String strQuery)
        throws SQLException
    {
        int i_return_value = 0;
        try
        {
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            i_return_value = stmt.executeUpdate(strQuery);
        }
        catch(SQLException sqle)
        {
            System.out.println("SQL Insert Update Delete Error=" + sqle.getMessage());
        }
        finally
        {
            try
            {
                takeDownAsset();
            }
            catch(Exception asset_final_exp) { }
        }
        return i_return_value;
    }

    public boolean existData(String strQuery)
    {
        boolean flag=false;
        try
        {
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            rs = stmt.executeQuery(strQuery);
            if(rs.next())
                flag = true;
            else
                flag = false;
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
        finally
        {
            try
            {
                rs.close();
                takeDownAsset();
            }
            catch(Exception asset_except) { }
        }
        return flag;
    }

    public Vector validLogin(String strQuery)
        throws SQLException
    {
        Vector result = null;
        try
        {
            result = new Vector();
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            rs = stmt.executeQuery(strQuery);
            if(rs.next())
            {
                result.addElement(rs.getString(1));
                result.addElement(rs.getString(2));
                result.addElement(rs.getString(3));
                result.addElement(rs.getString(4));
                result.addElement(rs.getString(5));
            } else
            {
                result.addElement("nil");
            }
            rs.close();
        }
        catch(Exception exception) { }
        finally
        {
            try
            {
                takeDownAsset();
            }
            catch(Exception asset_final_exp) { }
        }
        return result;
    }

    public ArrayList getRecords(String strQuery)
        throws SQLException
    {
        ArrayList recList=new ArrayList();
        try
        {
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            rs = stmt.executeQuery(strQuery);
			rsmd = rs.getMetaData();
			int numCols = rsmd.getColumnCount();
            while(rs.next())
            {
                ArrayList arr=new ArrayList();
                for(int i = 1; i <= numCols; i++)
                {
					///System.out.println("rsmd.getColumnType(i)>>"+rsmd.getColumnType(i));
					//System.out.println("rsmd.getColumnLabel(i)>>"+rsmd.getColumnLabel(i));
					switch(rsmd.getColumnType(i))
					{
					case 91: // '['
						Date date = rs.getDate(i);
						arr.add(date.toString());
						break;

					case 92: // '\\'
						Time time = rs.getTime(i);
						arr.add(time.toString());
						break;

					case 93: // ']'
						//Timestamp timestamp = rs.getTimestamp(i);
						String allchar1 = rs.getString(i);
						//System.out.println("allchar1.toString()>>"+allchar1);
						arr.add(allchar1);
						//arr.add(timestamp.toString());
						break;

					case -1:
					case 1: // '\001'
					case 12: // '\f'
						String allchar = rs.getString(i);
						arr.add(allchar);
						break;

					case 2: // '\002'
					case 3: // '\003'
						BigDecimal numeric = rs.getBigDecimal(i, 10);
						arr.add(numeric.toString());
						break;

					case -7:
						boolean bit = rs.getBoolean(i);
						arr.add(new Boolean(bit));
						break;

					case -6:
						byte tinyint = rs.getByte(i);
						arr.add(new Integer(tinyint));
						break;

					case 5: // '\005'
						short smallint = rs.getShort(i);
						arr.add(new Integer(smallint));
						break;

					case 4: // '\004'
						//int integer = rs.getInt(i);
						//arr.add(new Integer(integer));
						String allchar2 = rs.getString(i);
						arr.add(allchar2);
						break;

					case -5:
						long bigint = rs.getLong(i);
						arr.add(new Long(bigint));
						break;

					case 7: // '\007'
						float real = rs.getFloat(i);
						arr.add(new Float(real));
						break;

					case 6: // '\006'
					case 8: // '\b'
						double longreal = rs.getDouble(i);
						arr.add(new Double(longreal));
						break;

					case -4:
					case -3:
					case -2:
						byte binary[] = rs.getBytes(i);
						arr.add(new String(binary));
						break;
					}
				}
				recList.add(arr);
	  		}
            rs.close();
        }
        catch(SQLException sqlse)
        {
            System.out.println("SQL Insert Error=" + sqlse.getMessage());
        }
        finally
        {
            try
            {
                takeDownAsset();
            }
            catch(Exception expfin) { }
        }
        return recList;
    }

    public Vector getVector(String strQuery)
    {
        Vector common_vector = null;
        HashMap common_hash = null;
        ResultSet result = null;
        try
        {
            common_vector = new Vector();
            createAssetConnection();
            stmt = super.asset_dbCon.createStatement();
            result = stmt.executeQuery(strQuery);
            rsmd = result.getMetaData();
            int column_count = rsmd.getColumnCount();
            for(; result.next(); common_vector.addElement(common_hash))
            {
                common_hash = new HashMap();
                for(int i = 1; i <= column_count; i++)
                    common_hash.put(rsmd.getColumnLabel(i), result.getString(i));

            }

        }
        catch(Exception e)
        {
            System.out.println("SQL Exception ::" + e.getMessage());
        }
        finally
        {
            try
            {
                takeDownAsset();
            }
            catch(Exception asset_final_exp) { }
        }
        return common_vector;
    }

    public void cleanup()
    {
        try
        {
            stmt.close();
        }
        catch(SQLException SSE)
        {
            System.out.println("SQL Insert Error=" + SSE.getMessage());
        }
    }

    Statement stmt;
    ResultSet rs;
    ResultSetMetaData rsmd;
    CallableStatement callStmt;
    int status;
}