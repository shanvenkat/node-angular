package com.hybridshore.asset.common.util;

import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class ManagerCreator{

	public ManagerCreator(){
	}

	public Object getManager(ServletContext servletContext, String managerName){

		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		Object manager = wac.getBean(managerName);
		return manager;
	}
}