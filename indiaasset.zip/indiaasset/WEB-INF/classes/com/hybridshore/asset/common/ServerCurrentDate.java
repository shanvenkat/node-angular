// Author Name : Mr.K. Sivakumar & Mr.V.Venkateshan
// Decompiler options: packimports(3)
// Source File Name:   ServerCurrentDate.java

package com.hybridshore.asset.common;

import java.util.Date;

public class ServerCurrentDate
{

    public ServerCurrentDate()
    {
    }


    public String showTime_datetime(String s)
        throws Exception
    {
        Date date = new Date();
        String as[] = {
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "sep", "Oct",
            "Nov", "Dec"
        };
        int i = date.getDate();
        String s2 = as[date.getMonth()];
        int j = date.getMonth() + 1;
        int k = date.getYear() + 1900;
        int l = date.getHours();
        int i1 = date.getMinutes();
        int j1 = date.getSeconds();
        String s3 = "";
        if(s.equals("WithTime"))
            s3 = i + "-" + s2 + "-" + k + " " + l + ":" + i1 + ":" + j1;
        else
        if(s.equals("WithMonthAsNo"))
            s3 = i + "-" + j + "-" + k + "-" + l + "-" + i1 + "-" + j1;
        else
        if(s.equals("evaluation"))
            s3 = i + "-" + j + "-" + k + ":" + l + "." + i1 + "." + j1;
        else
        if(s.equals("for_status"))
            s3 = i + "-" + j + "-" + k + ":" + l + "." + i1 + "." + j1;
        else
        if(s.equals("WithMonthAsNoForRoute"))
            s3 = i + "-" + j + "-" + k + ":" + l + "-" + i1 + "-" + j1;
        else
        if(s.equals("DBChecker"))
            s3 = j + "/" + i + "/" + k;
        else
        if(s.equals("ForDatabase"))
            s3 = j + "/" + i + "/" + k + " " + l + ":" + i1 + ":" + j1;
        else
        if(s.equals("Time"))
            s3 = l + ":" + i1 + ":" + j1;
        else
        if(s.equals("for_secure"))
            s3 = s2 + i + k + l + i1 + j1;
        else
            s3 = i + "-" + s2 + "-" + k;
        return s3;
    }
    public String showTime(String access)
        throws Exception
    {
        Date d = new Date();
        String months[] = {
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "sep", "Oct",
            "Nov", "Dec"
        };
        int dt = d.getDate();
        String mon = months[d.getMonth()];
        int mont = d.getMonth() + 1;
        int yr = d.getYear() + 1900;
        int hrs = d.getHours();
        int mts = d.getMinutes();
        int sec = d.getSeconds();
        String dateTime = "";
        if(access.equals("WithTime"))
            dateTime = dt + "/" + mon + "/" + yr + " " + hrs + ":" + mts + ":" + sec;
        else
        if(access.equals("WithMonthAsNo"))
            dateTime = dt + "-" + mont + "-" + yr + "-" + hrs + "-" + mts + "-" + sec;
        else
        if(access.equals("Calendar"))
            dateTime = dt + "/" + mont + "/" + yr;
        else
            dateTime = dt + "-" + mon + "-" + yr;
        return dateTime;
    }

    public String getMonthNo(String month_str)
    {
        String month_no = "0";
        if(month_str.equals("Jan") | month_str.equals("jan") | month_str.equals("January"))
            month_no = "1";
        else
        if(month_str.equals("Feb") | month_str.equals("feb") | month_str.equals("Febuary"))
            month_no = "2";
        else
        if(month_str.equals("Mar") | month_str.equals("mar") | month_str.equals("March"))
            month_no = "3";
        else
        if(month_str.equals("Apr") | month_str.equals("apr") | month_str.equals("April"))
            month_no = "4";
        else
        if(month_str.equals("May") | month_str.equals("may"))
            month_no = "5";
        else
        if(month_str.equals("Jun") | month_str.equals("jun") | month_str.equals("June"))
            month_no = "6";
        else
        if(month_str.equals("Jul") | month_str.equals("jul") | month_str.equals("July"))
            month_no = "7";
        else
        if(month_str.equals("Aug") | month_str.equals("aug") | month_str.equals("August"))
            month_no = "8";
        else
        if(month_str.equals("Sep") | month_str.equals("sep") | month_str.equals("September"))
            month_no = "9";
        else
        if(month_str.equals("Oct") | month_str.equals("oct") | month_str.equals("October"))
            month_no = "10";
        else
        if(month_str.equals("Nov") | month_str.equals("nov") | month_str.equals("November"))
            month_no = "11";
        else
        if(month_str.equals("Dec") | month_str.equals("dec") | month_str.equals("December"))
            month_no = "12";
        return month_no;
    }
}