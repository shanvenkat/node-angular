// Author Name : Mr.K. Sivakumar & Mr.V.Venkateshan
// Decompiler options: packimports(3)
// Source File Name:   Path.java


package com.hybridshore.asset.common;

import java.net.URL;

public class Path
{

    public Path()
    {
    }

    public String loadPhysicalPath()
    {
        String url_path = null;
        try
        {
            URL url = getClass().getResource("/com/hybridshore/asset/common/Path.class");
            String query = url.getQuery();
            url_path = url.getPath();
            url_path = url_path.substring(0, url_path.indexOf("WEB-INF"));
            if(url_path != null)
                return url_path;
        }
        catch(Exception exception) { }
        return "0";
    }
}