package com.hybridshore.asset.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.StringTokenizer;

public class TimerThread implements Runnable {

	private String hr = null;
	private String min = null;
	private String sec = null;
	private String msec = null;
	private String ampm = null;

	private Calendar THREAD_START_TIME = null;

	Thread timerThread = null;


	/**
	 * @param refreshTime
	 */
	public void startThread(String hr,String min,String sec,String msec,String ampm) {

		this.hr = hr;
		this.min = min;
		this.sec = sec;
		this.msec = msec;
		this.ampm = ampm;
		timerThread = new Thread(this);
		timerThread.start();

		System.out.println("BI ::::: TIMER Thread Started");
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try {
			for (;;)
			{
				java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
				  //&& Calendar.get(Calendar.MILLISECOND)==Integer.parseInt(msec)
				if(Calendar.get(Calendar.HOUR)==Integer.parseInt(hr) && Calendar.get(Calendar.MINUTE)==Integer.parseInt(min) && Calendar.get(Calendar.SECOND)==Integer.parseInt(sec) && Calendar.get(Calendar.AM_PM)==Integer.parseInt(ampm))
				{
					new com.hybridshore.asset.web.QueryBean().moveExpire();
				}

				//Thread.sleep(  2 * 1000 * 60 * 60);
			}
		} catch (Exception lvObjEx) {
			System.out.println("BI ::::: Exception in TimerThread ==> "+ lvObjEx.getMessage());
			stopThread();
		}
	}




	public void stopThread() {
		if (timerThread != null) {
			timerThread.stop();
			timerThread = null;
			System.out.println("BI ::::: TIMER Thread Stopped");
		}
	}
}

