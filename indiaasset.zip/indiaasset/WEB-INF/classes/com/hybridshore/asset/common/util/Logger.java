// Decompiled by DJ v3.6.6.79 Copyright 2004 Atanas Neshkov  Date: 1/5/2006 11:25:55 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3)
// Source File Name:   Logger.java

package com.hybridshore.asset.common.util;


public interface Logger
{

    public abstract void log(Exception exception);

    public abstract void log(String s);

    public abstract void verbose(String s, int i);

    public abstract int getVerboseLevel();

    public abstract void setVerboseLevel(int i);

    public static final int VERBOSE_ALWAYS = 0;
    public static final int VERBOSE_HI_PRIORITY = 1;
    public static final int VERBOSE_LO_PRIORITY = 2;
    public static final int VERBOSE_VLO_PRIORITY = 3;
}