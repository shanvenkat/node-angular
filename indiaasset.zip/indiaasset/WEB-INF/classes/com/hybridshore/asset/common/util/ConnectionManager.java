// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 4/4/2005 1:08:51 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3)
// Source File Name:   ConnectionManager.java

package com.hybridshore.asset.common.util;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import javax.naming.*;
import javax.sql.DataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

// Referenced classes of package com.hybridshore.asset.common.util:
//            HybridFatalException, Resource, Trace, Logger

public class ConnectionManager
{

    public ConnectionManager()
    {
        logger = null;
    }

    public static void closeConnection(Connection dbConnection)
        throws HybridFatalException
    {
        if(dbConnection == null)
            return;
        try
        {
            dbConnection.close();
        }
        catch(SQLException e)
        {
            throw new HybridFatalException("SQL connection close returned error. SQLState :[" + e.getSQLState() + "] ErrorCode : [" + e.getErrorCode() + "]");
        }
    }

    public static void commitTransaction(Connection dbConnection)
        throws HybridFatalException
    {
        if(dbConnection == null)
            throw new HybridFatalException("Connection passed for performing commit is null");
        try
        {
            dbConnection.commit();
        }
        catch(SQLException sqlEx)
        {
            throw new HybridFatalException("SQL connection perform commit  error. SQLState :[" + sqlEx.getSQLState() + "] ErrorCode : [" + sqlEx.getErrorCode() + "]");
        }
    }

    public static void rollbackTransaction(Connection dbConnection)
        throws HybridFatalException
    {
        if(dbConnection == null)
            throw new HybridFatalException("Connection passed for performing rollback is null");
        try
        {
            dbConnection.rollback();
        }
        catch(SQLException sqlEx)
        {
            throw new HybridFatalException("SQL connection performing rollback error. SQLState :[" + sqlEx.getSQLState() + "] ErrorCode : [" + sqlEx.getErrorCode() + "]");
        }
    }

    public static synchronized Connection getAssetConnection()
        throws HybridFatalException
    {

        String DATA_SOURCE = null;
        String UserId = null;
        String Password = null;
        String contextFactory = null;
        Connection dbConnection = null;
		ManagerCreator mc = new ManagerCreator();

        /*
        if(asset_datasource == null)
        {

            Resource sampleConfig = Resource.getSampleConfig();
            DATA_SOURCE = sampleConfig.getString("HYBRIDASSET");
            UserId = sampleConfig.getString("DB_USER_ID");
            Password = sampleConfig.getString("DB_PWD_SEED");
            //contextFactory = sampleConfig.getString("INITIAL_CONTEXT_FACTORY");
            System.out.println("Property Intitialization done !!");
            try
            {
                //Hashtable parms = new Hashtable();
                //parms.put("java.naming.factory.initial", contextFactory);
                //Context ctx = new InitialContext(parms);
                System.out.println("INFO :: SET CONTEXT!!>>>");
                // Obtain our environment naming context
				Context ctx = (Context) new InitialContext().lookup("java:comp/env");
				System.out.println("AFTER!!");
				// Look up our data source
				asset_datasource = (DataSource) ctx.lookup(DATA_SOURCE);
                System.out.println("Context lookup done !!"+asset_datasource);
                ctx.close();
                System.out.println("Datasource Connected and Intitialization done !!");
            }
            catch(NamingException e)
            {
                throw new HybridFatalException("JNDI Name not found Exception during getConnection");
            }
        }
        */
        try
        {
			DriverManagerDataSource dataSource = (DriverManagerDataSource)mc.getManager(ServiceLocator.getContext(),"dataSource");
            //System.out.println("Datasource Connected and Intitialization done !!"+dataSource);
            dbConnection = dataSource.getConnection();
           // System.out.println("Datasource Connected and Intitialization done !!"+dbConnection);
            //dbConnection.setAutoCommit(true);
            return dbConnection;
        }
        catch(SQLException e)
        {
            Trace.printThrowable(e);
            e.printStackTrace();
            throw new HybridFatalException("SQL connection get returned error. Message:" + e.getMessage() + " SQLState :[" + e.getSQLState() + "] ErrorCode : [" + e.getErrorCode() + "]");
        }
    }

    Logger logger;
    static DataSource asset_datasource = null;

}