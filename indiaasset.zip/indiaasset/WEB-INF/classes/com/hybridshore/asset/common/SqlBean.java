// Author Name : Mr.K. Sivakumar & Mr.V.Venkateshan
// Decompiler options: packimports(3)
// Source File Name:   SqlBean.java

package com.hybridshore.asset.common;

import com.hybridshore.asset.common.util.ConnectionManager;
import com.hybridshore.asset.common.util.HybridFatalException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;

public abstract class SqlBean
{

    public SqlBean()
    {
    }

    public void createAssetConnection()
    {
        try
        {
            asset_dbCon = ConnectionManager.getAssetConnection();
        }
        catch(Exception exception)
        {
            System.out.println("Error in asset/common/SqlBean createAssetConnection():" + exception.getMessage());
        }
    }

    public void takeDownAsset()
        throws SQLException, HybridFatalException
    {
        try
        {
            cleanup();
            if(asset_dbCon != null)
                ConnectionManager.closeConnection(asset_dbCon);
        }
        catch(SQLException sqlexception)
        {
            System.out.println("Error in asset/common/SqlBean takeDown():" + sqlexception.getMessage());
        }
    }
    public void commitAssetTransaction()
        throws SQLException, HybridFatalException
    {
        if(asset_dbCon != null)
            ConnectionManager.commitTransaction(asset_dbCon);
    }
    public void rollbackAssetTransaction()
        throws SQLException, HybridFatalException
    {
        if(asset_dbCon != null)
            ConnectionManager.rollbackTransaction(asset_dbCon);
    }
    public abstract void cleanup()
        throws SQLException;

    protected Connection asset_dbCon;
}