
/**
* Owner					    : iGrandee
* @author				    : K.Sivakumar & R.Manoharan
* Date					    : Oct-10-2003
* Description			    : StartupListener class used to initialize and database settings
*							: and populate any application-wide drop-downs.
* @version				    : 1.0
* --------------------Modification History----------------------------------------
* Modification Number		:
* Date						:
* Modified By				:
* Documented By				: iGrandians
* Description				:
* Version					:
* --------------------Modification History----------------------------------------
*/

package com.hybridshore.asset.common.util;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;

public class StartupListener implements ServletContextListener
{
    ServletContext servletContext;
	TimerThread timerThread = null;  //TIMER
	/**
	*
	*@param (sce) as ServletContextEvent
	*@return void
	*/

	public void contextInitialized(ServletContextEvent sce)
	{
		Properties  props =null;
		InputStream in=null;
		String persistent_type = "HIBERNATE";
		Resource sampleConfig = Resource.getSampleConfig();
		String hour=sampleConfig.getString("AUTO_HOUR");
		String min=sampleConfig.getString("AUTO_MINUTE");
		String sec=sampleConfig.getString("AUTO_SECOND");
		String msec=sampleConfig.getString("AUTO_MILLISECOND");
		String ampm=sampleConfig.getString("AUTO_AM_PM");
		String ampm_type="0";
		if(ampm.equalsIgnoreCase("AM"))
		   ampm_type="0";
		else
		   ampm_type="1";
		System.out.println("HOUR>>"+hour+"  MIN>>"+min+"  SEC>>"+sec+"  MSEC>>"+msec+"  TYPE>>"+ampm_type);

		try
		{
			servletContext = sce.getServletContext();
			ServiceLocator servicelocator = new ServiceLocator(servletContext);
			timerThread = new TimerThread();  //TIMER
			timerThread.startThread(hour,min,sec,msec,ampm_type);  //TIMER
		}
		catch(Exception exp)
		{
			System.out.println("Exception  :"+exp.getMessage());
		}
		// all Context Parameters present and valid...
	}
	/**
	*
	*@param (sce) as ServletContextEvent
	*@return void
	*/

	public void contextDestroyed(ServletContextEvent sce)
	{
        //System.out.println("contextDestroyed");
        servletContext = null;
        timerThread.stopThread();  //TIMER
    }
}
//EOF