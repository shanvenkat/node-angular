// Decompiled by DJ v3.6.6.79 Copyright 2004 Atanas Neshkov  Date: 1/5/2006 11:26:01 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3)
// Source File Name:   HybridFatalException.java

package com.hybridshore.asset.common.util;

import java.io.PrintStream;

public class HybridFatalException extends Exception
{

    public HybridFatalException(String message)
    {
        System.out.println("EXC " + message);
    }
}