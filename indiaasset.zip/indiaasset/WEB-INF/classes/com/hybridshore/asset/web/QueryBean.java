// AUTHOR : K. SIVAKUMAR & Annan
// Decompiler options: packimports(3)
// Source File Name:   QueryBean.java

package com.hybridshore.asset.web;

import com.hybridshore.asset.common.DataBaseMediator;
import java.util.Vector;
import java.util.ArrayList;
public class QueryBean
{

    public QueryBean()
    {
        dbm = new DataBaseMediator();
    }

    public Vector userValidation(String email,String pwd)
    {
		Vector vec=null;
		try
		{
            vec=new Vector();
            String qry= "select LOGINEMAILADDRESS from register where LOGINEMAILADDRESS='"+email+"'";
            if(dbm.existData(qry))
            {
				qry= "select USERPWD from register where LOGINEMAILADDRESS='"+email+"' and USERPWD='"+pwd+"'";
				if(dbm.existData(qry))
				{
					vec=dbm.validLogin("select ID,LOGINEMAILADDRESS,MYNAME,FAMILYNAME,DATECREATED from register where LOGINEMAILADDRESS='"+email+"' and USERPWD='"+pwd+"'");
				}
				else
				{
					vec.addElement("Invalid Password");
				}
			}
			else
			{
				vec.addElement("Invalid Email");
			}

		}
		catch(Exception ex){}
		return vec;


	}
    public Vector adminValidation(String user,String pwd)
    {
		Vector vec=null;
		try
		{
            vec=new Vector();
            String qry= "select user from admin_tb where user='"+user+"' and password='"+pwd+"'";
            if(dbm.existData(qry))
            {
				vec.addElement(user);
			}
			else
			{
				vec.addElement("Invalid User/Password");
			}

		}
		catch(Exception ex){}
		return vec;
	}

	public int updatePropertyImage(String propid,String attachimage,String attachment,String tablename)
	{
        int count=0;
        try
        {
System.out.println("exists db....."+attachimage);
System.out.println("attach....."+attachment);

			java.util.StringTokenizer st=new java.util.StringTokenizer(attachimage,",");
			String img1=st.nextToken();
			String img2=st.nextToken();
			String img3=st.nextToken();

			java.util.StringTokenizer st1=new java.util.StringTokenizer(attachment,",");
			String img11=st1.nextToken();
			String img22=st1.nextToken();
			String img33=st1.nextToken();

			String str="";
			if(!img1.equals("null"))
			{
			  str+=img1+",";
			}
			else{str+=img11+",";}
			if(!img2.equals("null"))
			{
			  str+=img2+",";
			}
			else{str+=img22+",";}
			if(!img3.equals("null"))
			{
			  str+=img3+",";
			}
			else{str+=img33+",";}

			if(str.length()>1)
			{str=str.substring(0,str.length()-1);}
			String qry= "";
            if(tablename.equals("home_for_sale"))
            {
            qry= "update home_for_sale set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "update land_for_sale set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
			qry= "update apartment_for_sale set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
			qry= "update business_property_for_sale set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
			qry= "update apartment_for_lease_rent set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
			qry= "update business_property_for_lease_rent set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
			qry= "update home_for_lease_rent set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
			qry= "update land_for_lease_rent set ATTACHIMAGE='"+str+"' where PROPERTYID='"+propid+"'";
			}
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);

        }
        catch(Exception exception) { }
        return count;
	}

	public int editPropertyImage(String propid,String attach,String tablename)
	{
        int count=0;
        try
        {
			String qry= "";
            if(tablename.equals("home_for_sale"))
            {
            qry= "update home_for_sale set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "update land_for_sale set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
			qry= "update apartment_for_sale set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
			qry= "update business_property_for_sale set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
			qry= "update apartment_for_lease_rent set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
			qry= "update business_property_for_lease_rent set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
			qry= "update home_for_lease_rent set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
			qry= "update land_for_lease_rent set ATTACHIMAGE='"+attach+"' where PROPERTYID='"+propid+"'";
			}
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);

        }
        catch(Exception exception) { }
        return count;
	}
	/*public int updatePropertyInfo(String propid,String ptype,String sqft,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc)
	{
        int count=0;
        try
        {
			String qry= "update property set PROPERTYTYPE_ID="+ptype+",APPROXSQFT='"+sqft+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);

        }
        catch(Exception exception) { }
        return count;
	}*/
	// UPDATE HOME FOR SALE
	public int updatePropertyInfo_hsale(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String landsize,String sqft,String barea,String room,String bage,String price_sqft)
	{
        int count=0;
        try
        {
			String qry= "update home_for_sale set APPROXSIZE='"+landsize+"',APPROXSQFT='"+sqft+"',BUILDINGAREA='"+barea+"',BEDROOMS='"+room+"',BUILDINGAGE='"+bage+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}
	// UPDATE LAND FOR SALE
	public int updatePropertyInfo_lsale(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String landsize,String sqft,String price_sqft)
	{
        int count=0;
        try
        {
			String qry= "update land_for_sale set APPROXSIZE='"+landsize+"',APPROXSQFT='"+sqft+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}
	// UPDATE APARTMENT FOR SALE
	public int updatePropertyInfo_asale(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String barea,String room,String bage,String price_sqft)
	{
        int count=0;
        try
        {
			String qry= "update apartment_for_sale set APARTMENTAREA='"+barea+"',BEDROOMS='"+room+"',BUILDINGAGE='"+bage+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}
	// UPDATE BUSINESS PROPERTY FOR SALE
	public int updatePropertyInfo_bsale(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String barea,String bage,String price_sqft)
	{
        int count=0;
        try
        {
			String qry= "update business_property_for_sale set BUSINESSPROPERTY_AREA='"+barea+"',BUILDINGAGE='"+bage+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}

	// UPDATE APARTMENT FOR LEASE/RENT
	public int updatePropertyInfo_alease(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String barea,String room,String bage,String price_sqft,String period,String deposit)
	{
        int count=0;
        try
        {
			String qry= "update apartment_for_lease_rent set APARTMENTAREA='"+barea+"',BEDROOMS='"+room+"',BUILDINGAGE='"+bage+"',LEASEPERIOD='"+period+"',DEPOSITAMOUNT='"+deposit+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}

	// UPDATE BUSINESS PROPERTY FOR LEASE/RENT
	public int updatePropertyInfo_blease(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String barea,String bage,String price_sqft,String period,String deposit)
	{
        int count=0;
        try
        {
			String qry= "update business_property_for_lease_rent set BUSINESSPROPERTY_AREA='"+barea+"',BUILDINGAGE='"+bage+"',LEASEPERIOD='"+period+"',DEPOSITAMOUNT='"+deposit+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}

	// UPDATE HOME FOR LEASE/RENT
	public int updatePropertyInfo_hlease(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String landsize,String sqft,String barea,String room,String bage,String price_sqft,String period,String deposit)
	{
        int count=0;
        try
        {
			String qry= "update home_for_lease_rent set APPROXSIZE='"+landsize+"',APPROXSQFT='"+sqft+"',BUILDINGAREA='"+barea+"',BEDROOMS='"+room+"',BUILDINGAGE='"+bage+"',LEASEPERIOD='"+period+"',DEPOSITAMOUNT='"+deposit+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}

	// UPDATE LAND FOR SALE
	public int updatePropertyInfo_llease(String propid,String ptype,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String desc,String landsize,String sqft,String price_sqft,String period,String deposit)
	{
        int count=0;
        try
        {
			String qry= "update land_for_lease_rent set APPROXSIZE='"+landsize+"',APPROXSQFT='"+sqft+"',LEASEPERIOD='"+period+"',DEPOSITAMOUNT='"+deposit+"',SELLERTYPE_ID="+type_seller+",LOCATIONDETAILS='"+location+"',CONTACTPERSON='"+contactname+"',ADDRESSLINE1='"+address1+"',ADDRESSLINE2='"+address2+"',ADDRESSLINE3='"+address3+"',CITY='"+city+"',STATE_ID='"+state+"',PINCODE='"+pincode+"',PHONE1='"+phone1+"',PHONE2='"+phone2+"',PHONE3='"+phone3+"',CONTACTEMAILADDRESS='"+contactemail+"',PRICESQFT='"+price_sqft+"',PROPERTYPRICE='"+price+"',PROPERTYDESC='"+desc+"',NOPROPERTYPRICE='"+pricetype+"' where PROPERTYID='"+propid+"'";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
	}

// INSERT HOME FOR SALE

    public long insertPropertyInfo_hsale(String idValue,String ptype,String landsize,String sqft,String barea,String room,String bage,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from home_for_sale");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into home_for_sale(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APPROXSIZE,APPROXSQFT,BUILDINGAREA,BUILDINGAGE,BEDROOMS,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+landsize+"','" + sqft+ "','"+barea+"','"+bage+"','"+room+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT LAND FOR SALE

    public long insertPropertyInfo_lsale(String idValue,String ptype,String landsize,String sqft,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from land_for_sale");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into land_for_sale(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APPROXSIZE,APPROXSQFT,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+landsize+"','" + sqft+ "',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT APARTMENT FOR SALE

    public long insertPropertyInfo_asale(String idValue,String ptype,String barea,String room,String bage,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from apartment_for_sale");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into apartment_for_sale(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APARTMENTAREA,BUILDINGAGE,BEDROOMS,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+barea+"','"+bage+"','"+room+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT BUSINESS PROPERTY FOR SALE

    public long insertPropertyInfo_bsale(String idValue,String ptype,String barea,String bage,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from business_property_for_sale");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into business_property_for_sale(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,BUSINESSPROPERTY_AREA,BUILDINGAGE,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+barea+"','"+bage+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT APARTMENT FOR LEASE/RENT

    public long insertPropertyInfo_alease(String idValue,String ptype,String barea,String room,String bage,String period,String deposit,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from apartment_for_lease_rent");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into apartment_for_lease_rent(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APARTMENTAREA,BUILDINGAGE,BEDROOMS,LEASEPERIOD,DEPOSITAMOUNT,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+barea+"','"+bage+"','"+room+"','"+period+"','"+deposit+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT BUSINESS PROPERTY FOR LEASE/RENT

    public long insertPropertyInfo_blease(String idValue,String ptype,String barea,String bage,String period,String deposit,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from business_property_for_lease_rent");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into business_property_for_lease_rent(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,BUSINESSPROPERTY_AREA,BUILDINGAGE,LEASEPERIOD,DEPOSITAMOUNT,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+barea+"','"+bage+"','"+period+"','"+deposit+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT HOME FOR LEASE/RENT

    public long insertPropertyInfo_hlease(String idValue,String ptype,String landsize,String sqft,String barea,String room,String bage,String period,String deposit,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from home_for_lease_rent");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into home_for_lease_rent(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APPROXSIZE,APPROXSQFT,BUILDINGAREA,BUILDINGAGE,BEDROOMS,LEASEPERIOD,DEPOSITAMOUNT,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+landsize+"','" + sqft+ "','"+barea+"','"+bage+"','"+room+"','"+period+"','"+deposit+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

// INSERT LAND FOR LEASE/RENT

    public long insertPropertyInfo_llease(String idValue,String ptype,String landsize,String sqft,String period,String deposit,String type_seller,String location,String contactname,String address1,String address2,String address3,String city,String state,String pincode,String phone1,String phone2,String phone3,String contactemail,String price,String pricetype,String price_sqft,String desc,String attachment,String myname,String email)
    {
        long count=0;
        try
        {
					String dayid="0";
					ArrayList days_list=getPostingDays();
					for(int i=0;i<days_list.size();i++)
					{
					     ArrayList arr=(ArrayList)days_list.get(i);
					     dayid=arr.get(0).toString();
					}
					if(days_list.size()==0)
					{
						String qry= "update postingdays set ACTIVE_FLAG='D'";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);

						long id1=dbm.fmaxId("select max(DAY_ID) from postingdays");
						qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id1+",'90','A')";
						System.out.println("ASSET QRY >>"+qry);
						count= dbm.insertUpdateDeleteRecord(qry);
					    dayid=new Long(id1).toString();
					}
					days_list=null;


			long id=dbm.fmaxId("select max(PROPERTYID) from property");
			long id1=dbm.fmaxId("select max(PROPERTY_SUBID) from land_for_lease_rent");

			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));

			//0000-00-00 00:00:00
			String qry= "insert into property(PROPERTYID,PROPERTYTYPE_ID) values("+id+"," + ptype + ")";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);


			qry= "insert into land_for_lease_rent(PROPERTY_SUBID,ID,PROPERTYID,PROPERTYSTATUS,PROPERTYTYPE_ID,APPROXSIZE,APPROXSQFT,LEASEPERIOD,DEPOSITAMOUNT,SELLERTYPE_ID,LOCATIONDETAILS,CONTACTPERSON,ADDRESSLINE1,ADDRESSLINE2,ADDRESSLINE3,CITY,STATE_ID,PINCODE,PHONE1,PHONE2,PHONE3,CONTACTEMAILADDRESS,ATTACHIMAGE,PRICESQFT,PROPERTYPRICE,NOPROPERTYPRICE,PROPERTYDESC,DAY_ID,DATECREATED,ACTIVEDATE) values("+id1+"," + idValue + ","+id+",'D'," + ptype + ",'"+landsize+"','" + sqft+ "','"+period+"','"+deposit+"',"+type_seller+",'" + location+ "','"+contactname+"','" + address1+ "','"+address2+"','" + address3+ "','"+city+"'," + state+ ",'"+pincode+"','" + phone1+ "','"+phone2+"','" + phone3+ "','"+contactemail+"','" + attachment+ "','"+price_sqft+"','"+price+"','" + pricetype+ "','"+desc+"',"+dayid+",'"+dat+"','"+dat+"')";
			System.out.println("ASSET QRY >>"+qry);
			int count1= dbm.insertUpdateDeleteRecord(qry);
			if(count1==0)
			{
				int count2= dbm.insertUpdateDeleteRecord("delete from property where PROPERTYID='"+id+"'");
			}
			else
			{
				if(count==1)
				{
					count=id;
				}
			}
        }
        catch(Exception exception) { }
        return count;
    }

    public int insertPayment(String tablename,String myname,String email,String infoid,String method,String cardname,String cardno,String cardtype,String cvv2,String month,String year,String toll)
    {
        int count=0;
        try
        {
			long id=dbm.fmaxId("select max(PAYMENTID) from payment");
			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
			String exp=year+"-"+month+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
			//0000-00-00 00:00:00
			String qry= "insert into payment(PAYMENTID,PROPERTYID,PRICE_ID,NAMEONCARD,CREDITCARDNUM,CVV2NUMBER,CARDTYPE_ID,MONTHEXPIRATION,YEAREXPIRATION,TOLLFREENUM,DATECREATED) values("+id+"," + infoid + "," + method + ",'" + cardname+ "','"+cardno+"','" + cvv2+ "',"+cardtype+","+month+","+year+",'"+toll+"','" + dat+ "')";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);

			if(count==1)
			{
				String ptype="";
				if(tablename.equals("home_for_sale"))
				{ptype="HOME FOR SALE";}
				else if(tablename.equals("land_for_sale"))
				{ptype="LAND FOR SALE";}
				else if(tablename.equals("apartment_for_sale"))
				{ptype="APARTMENT FOR SALE";}
				else if(tablename.equals("business_property_for_sale"))
				{ptype="BUSINESS PROPERTY FOR SALE";}
				else if(tablename.equals("apartment_for_lease_rent"))
				{ptype="APARTMENT FOR LEASE/RENT";}
				else if(tablename.equals("business_property_for_lease_rent"))
				{ptype="BUSINESS PROPERTY FOR LEASE/RENT";}
				else if(tablename.equals("home_for_lease_rent"))
				{ptype="HOME FOR LEASE/RENT";}
				else if(tablename.equals("land_for_lease_rent"))
				{ptype="LAND FOR LEASE/RENT";}
				String pid="PID_"+infoid;

				// MAIL COMPOSING HERE
				ComposeMail cmail=new ComposeMail();
				String msg=myname+"/"+email+", added new property in the system.\n\nProperty ID: "+pid+"\nProperty Type: "+ptype+"\n\n  Please login and activate the property after checking payment.";
				cmail.sendMail_ToAdmin("New PROPERTY Added into BhoomiIndia system",msg);
				cmail=null;
			}


        }
        catch(Exception exception) { }
        return count;
    }
public void forgetPWD(String email)
{
	try
	{
	// MAIL COMPOSING HERE
	ComposeMail cmail=new ComposeMail();
	String msg=email+", Forgot password in the BhoomiIndia system.  Please my password send me.";
	cmail.sendMail_ToAdmin("Forget My Password - BhoomiIndia",msg);
	cmail=null;
	}catch(Exception es){}
}


	public int insertPropertyType(String ptype,String tb)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(PROPERTYTYPE_ID) from propertytype");
				String qry= "insert into propertytype(PROPERTYTYPE_ID,DESCRIPTION,ACTIVE_FLAG,PROPERTY_TABLE) values("+id+",'"+ptype+"','A','"+tb+"')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updatePropertyType(String pid,String ptype,String tb)
	{
			int count=0;
			try
			{
				String qry= "update propertytype set DESCRIPTION='"+ptype+"',PROPERTY_TABLE='"+tb+"' where PROPERTYTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deletePropertyType(String pid)
	{
			int count=0;
			try
			{
				String qry= "update propertytype set ACTIVE_FLAG='D' where PROPERTYTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	// INSERT SELLER TYPE

	public int insertSellerType(String ptype)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(SELLERTYPE_ID) from sellertype");
				String qry= "insert into sellertype(SELLERTYPE_ID,DESCRIPTION,ACTIVE_FLAG) values("+id+",'"+ptype+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updateSellerType(String pid,String ptype)
	{
			int count=0;
			try
			{
				String qry= "update sellertype set DESCRIPTION='"+ptype+"' where SELLERTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deleteSellerType(String pid)
	{
			int count=0;
			try
			{
				String qry= "update sellertype set ACTIVE_FLAG='D' where SELLERTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	// INSERT NEWS

	public int insertNews(String ptype)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(NEWS_ID) from news");
				String qry= "insert into news(NEWS_ID,DESCRIPTION,ACTIVE_FLAG) values("+id+",'"+ptype+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updateNews(String pid,String ptype)
	{
			int count=0;
			try
			{
				String qry= "update news set DESCRIPTION='"+ptype+"' where NEWS_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deleteNews(String pid)
	{
			int count=0;
			try
			{
				//String qry= "update news set ACTIVE_FLAG='D' where NEWS_ID='"+pid+"'";
				String qry= "delete from news where NEWS_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	// INSERT STATE

	public int insertState(String ptype)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(STATE_ID) from state");
				String qry= "insert into state(STATE_ID,DESCRIPTION,ACTIVE_FLAG) values("+id+",'"+ptype+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updateState(String pid,String ptype)
	{
			int count=0;
			try
			{
				String qry= "update state set DESCRIPTION='"+ptype+"' where STATE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deleteState(String pid)
	{
			int count=0;
			try
			{
				String qry= "update state set ACTIVE_FLAG='D' where STATE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}
// INSERT CARD TYPE

	public int insertCardType(String ptype)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(CARDTYPE_ID) from cardtype");
				String qry= "insert into cardtype(CARDTYPE_ID,DESCRIPTION,ACTIVE_FLAG) values("+id+",'"+ptype+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updateCardType(String pid,String ptype)
	{
			int count=0;
			try
			{
				String qry= "update cardtype set DESCRIPTION='"+ptype+"' where CARDTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deleteCardType(String pid)
	{
			int count=0;
			try
			{
				String qry= "update cardtype set ACTIVE_FLAG='D' where CARDTYPE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

// POSTING DAYS

	// INSERT STATE

	public int insertDays(String ptype)
	{
			int count=0;
			try
			{
				String qry= "update postingdays set ACTIVE_FLAG='D'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);

				long id=dbm.fmaxId("select max(DAY_ID) from postingdays");
				qry= "insert into postingdays(DAY_ID,DESCRIPTION,ACTIVE_FLAG) values("+id+",'"+ptype+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updateDays(String pid,String ptype)
	{
			int count=0;
			try
			{
				String qry= "update postingdays set DESCRIPTION='"+ptype+"' where DAY_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deleteDays(String pid)
	{
			int count=0;
			try
			{
				String qry= "update postingdays set ACTIVE_FLAG='D' where DAY_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}


// POSTING PRICE

	// INSERT PRICE

	public int insertPrice(String price,String currency,String method,String mode)
	{
			int count=0;
			try
			{
				long id=dbm.fmaxId("select max(PRICE_ID) from postingprice");
				String qry= "insert into postingprice(PRICE_ID,ADVTPRICE,PAYMENTMETHOD,CURRENCYTYPE,MODE,ACTIVE_FLAG) values("+id+",'"+price+"','"+method+"','"+currency+"','"+mode+"','A')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int updatePrice(String pid,String price,String currency,String method,String mode)
	{
			int count=0;
			try
			{
				String qry= "update postingprice set ADVTPRICE='"+price+"',PAYMENTMETHOD='"+method+"',CURRENCYTYPE='"+currency+"',MODE='"+mode+"' where PRICE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}

	public int deletePrice(String pid)
	{
			int count=0;
			try
			{
				String qry= "update postingprice set ACTIVE_FLAG='D' where PRICE_ID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}
			catch(Exception exception) { }
			return count;
	}


    public int insertPaymentDD(String tablename,String myname,String email,String infoid,String method)
    {
        int count=0;
        try
        {
			long id=dbm.fmaxId("select max(PAYMENTID) from payment");
			java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
			String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
			//0000-00-00 00:00:00
			String qry= "insert into payment(PAYMENTID,PROPERTYID,PRICE_ID,DATECREATED) values("+id+"," + infoid + "," + method + ",'" + dat+ "')";
			System.out.println("ASSET QRY >>"+qry);
			count= dbm.insertUpdateDeleteRecord(qry);

			if(count==1)
			{
				String ptype="";
				if(tablename.equals("home_for_sale"))
				{ptype="HOME FOR SALE";}
				else if(tablename.equals("land_for_sale"))
				{ptype="LAND FOR SALE";}
				else if(tablename.equals("apartment_for_sale"))
				{ptype="APARTMENT FOR SALE";}
				else if(tablename.equals("business_property_for_sale"))
				{ptype="BUSINESS PROPERTY FOR SALE";}
				else if(tablename.equals("apartment_for_lease_rent"))
				{ptype="APARTMENT FOR LEASE/RENT";}
				else if(tablename.equals("business_property_for_lease_rent"))
				{ptype="BUSINESS PROPERTY FOR LEASE/RENT";}
				else if(tablename.equals("home_for_lease_rent"))
				{ptype="HOME FOR LEASE/RENT";}
				else if(tablename.equals("land_for_lease_rent"))
				{ptype="LAND FOR LEASE/RENT";}
				String pid="PID_"+infoid;

				// MAIL COMPOSING HERE
				ComposeMail cmail=new ComposeMail();
				String msg=myname+"/"+email+", added new property in the system.\n\nProperty ID: "+pid+"\nProperty Type: "+ptype+"\n\n  Please login and activate the property after checking payment.";
				cmail.sendMail_ToAdmin("New PROPERTY Added into BhoomiIndia system",msg);
				cmail=null;
			}


        }
        catch(Exception exception) { }
        return count;
    }

    public int insertMember(String my,String family,String email,String pwd)
    {
        int count=0;
        try
        {
            String qry1= "select ID,LOGINEMAILADDRESS from register where LOGINEMAILADDRESS='"+email+"'";
            if(dbm.existData(qry1))
            {
				count=110;
			}
			else
			{
				my=my.replace('\'','`');
				family=family.replace('\'','`');
				long id=dbm.fmaxId("select max(ID) from register");
				java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
				String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
				//0000-00-00 00:00:00
				String qry= "insert into register(ID,LOGINEMAILADDRESS,MYNAME,FAMILYNAME,USERPWD,DATECREATED) values("+id+",'" + email + "','" + my + "','" + family + "','" + pwd+ "','"+dat+"')";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
			}


			if(count==1)
			{
				// MAIL COMPOSING HERE
				ComposeMail cmail=new ComposeMail();
				String msg="New Member Added. User email address is "+email+", name is "+my;
				cmail.sendMail_ToAdmin("New Member Added (BhoomiIndia)",msg);
				cmail=null;
			}


        }
        catch(Exception exception) { }
        return count;
    }
public int changeStatus(String category,String pid,String cardno,String cardtype,String payid,String tablename)
{
        int count=0;
        try
        {
				java.util.GregorianCalendar Calendar=new java.util.GregorianCalendar();
				String dat=Integer.toString(Calendar.get(Calendar.YEAR))+"-"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"-"+Integer.toString(Calendar.get(Calendar.DATE))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
				String qry= "";
				if(tablename.equals("home_for_sale"))
				{
					qry= "update home_for_sale set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("land_for_sale"))
				{
					qry= "update land_for_sale set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("apartment_for_sale"))
				{
					qry= "update apartment_for_sale set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("business_property_for_sale"))
				{
					qry= "update business_property_for_sale set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
					qry= "update apartment_for_lease_rent set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
					qry= "update business_property_for_lease_rent set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
					qry= "update home_for_lease_rent set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
					qry= "update land_for_lease_rent set PROPERTYSTATUS='A',ACTIVEDATE='"+dat+"' where PROPERTYID='"+pid+"'";
				}
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);

				if(count!=0)
				{
					ArrayList rec_list=getData_ForMail(pid,payid,cardtype,tablename);

					//0 p.PROPERTYID, 1 p.CONTACTPERSON, 2 p.CONTACTEMAILADDRESS, 3 e.DESCRIPTION,
					//4 p1.CREDITCARDNUM, 5 p1.MONTHEXPIRATION, 6 p1.YEAREXPIRATION, 7 p1.NAMEONCARD,
					//8 p1.CVV2NUMBER, 9 p1.TOLLFREENUM, 10 p1.PAYMENTID 11 RS
					String cname="",to="",ctype="",cnum="",mon="",year="",cardname="",cvv2="",toll="",rupee="";
					for(int i=0;i<rec_list.size();i++)
					{
						 ArrayList arr=(ArrayList)rec_list.get(i);
						 cname=arr.get(1).toString();
						 to=arr.get(2).toString();
						 ctype=arr.get(3).toString();
						 cnum=arr.get(4).toString();
						 mon=arr.get(5).toString();
						 year=arr.get(6).toString();
						 cardname=arr.get(7).toString();
						 cvv2=arr.get(8).toString();
						 toll=arr.get(9).toString();
						 rupee=arr.get(11).toString();
						 break;
					}
					if(cnum!=null)
					{

						///----------------------
						cnum=cnum.replace('�','5');cnum=cnum.replace('�','6');
						cnum=cnum.replace('�','1');cnum=cnum.replace('�','2');
						cnum=cnum.replace('�','3');cnum=cnum.replace('�','4');
						cnum=cnum.replace('�','0');cnum=cnum.replace('�','7');
						cnum=cnum.replace('�','8');cnum=cnum.replace('�','9');
						String enc="";
						java.util.StringTokenizer str=new java.util.StringTokenizer(cnum,"�");
						while(str.hasMoreTokens())
						{
							String s=str.nextToken();
							int k=Integer.parseInt(s);
							char ds=(char)k;
							enc+=ds+"";
						}
						String org="";
						for(int i1=enc.length()-1;i1>=0;i1--)
						{
							char c=enc.charAt(i1);
							org+=c+"";
						}
						cnum=org;
						///----------------------


                	    if(cnum.length()>4)
                	    {cnum="XXXXXXXXXXXXX"+cnum.substring(cnum.length()-3,cnum.length());}
                	    else{cnum="XXXXXXXXXXXXXXXX";}
					}

				String ptype="";
				if(tablename.equals("home_for_sale"))
				{ptype="HOME FOR SALE";}
				else if(tablename.equals("land_for_sale"))
				{ptype="LAND FOR SALE";}
				else if(tablename.equals("apartment_for_sale"))
				{ptype="APARTMENT FOR SALE";}
				else if(tablename.equals("business_property_for_sale"))
				{ptype="BUSINESS PROPERTY FOR SALE";}
				else if(tablename.equals("apartment_for_lease_rent"))
				{ptype="APARTMENT FOR LEASE/RENT";}
				else if(tablename.equals("business_property_for_lease_rent"))
				{ptype="BUSINESS PROPERTY FOR LEASE/RENT";}
				else if(tablename.equals("home_for_lease_rent"))
				{ptype="HOME FOR LEASE/RENT";}
				else if(tablename.equals("land_for_lease_rent"))
				{ptype="LAND FOR LEASE/RENT";}

					// MAIL COMPOSING HERE
					ComposeMail cmail=new ComposeMail();
					String msg="";
					String dattime=Integer.toString(Calendar.get(Calendar.DATE))+"/"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"/"+Integer.toString(Calendar.get(Calendar.YEAR))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
					if(ctype.equalsIgnoreCase("Cheque/DD"))
					{
					   msg="\nYour Property is ACTIVATE NOW\n\nBHOOMI INDIA\n\nDate & Time: "+dattime+"\nProperty ID: PID_"+pid+"\nProperty Type: "+ptype+"\nPayment ID: PAY_"+payid+"\n\nThanks for payment(Cheque/DD).\n\n\n(note: Please take the printout for a future records & communcation)";
				    }
					else
					{
					   msg="\nYour Property is ACTIVATE NOW\n\nBHOOMI INDIA\n\nDate & Time: "+dattime+"\nProperty ID: PID_"+pid+"\nProperty Type: "+ptype+"\nPayment ID: PAY_"+payid+"\nPrice: "+rupee+"\nCard Name: "+cardname+"\nCard No.: "+cnum+"\nCard Type: "+ctype+"\nCVV2 No.: "+cvv2+"\nToll Free No.: "+toll+"\n\nThanks for payment.\n\n\n(note: Please take the printout for a future records & communcation)";
				    }
					cmail.sendMail_FromAdmin("Your Property is ACTIVATE NOW (BhoomiIndia)",msg,to);
					cmail=null;
					cname=null;to=null;ctype=null;cnum=null;mon=null;year=null;cardname=null;cvv2=null;toll=null;
				}




        }
        catch(Exception exception) { }
        return count;
}

public int sendMail(String to,String msg)
{
    int count=0;
    try
    {
	count=1;
	// MAIL COMPOSING HERE
	ComposeMail cmail=new ComposeMail();
	//String dattime=Integer.toString(Calendar.get(Calendar.DATE))+"/"+Integer.toString(Calendar.get(Calendar.MONTH)+1)+"/"+Integer.toString(Calendar.get(Calendar.YEAR))+" "+Integer.toString(Calendar.get(Calendar.HOUR))+":"+Integer.toString(Calendar.get(Calendar.MINUTE))+":"+Integer.toString(Calendar.get(Calendar.SECOND));
	cmail.sendMail_FromAdmin_HTML("Property Details (BhoomiIndia)",msg,to);
	cmail=null;
    }
    catch(Exception es){count=0;}
    return count;
}
	public ArrayList getData_ForMail(String pid,String payid,String ctype,String tablename)
	{
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
			if(tablename.equals("home_for_sale"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from home_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from home_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("land_for_sale"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from land_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from land_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("apartment_for_sale"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from apartment_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from apartment_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("business_property_for_sale"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from business_property_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from business_property_for_sale p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from apartment_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from apartment_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from business_property_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from business_property_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from home_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from property p, home_for_lease_rent p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
				if(ctype.equalsIgnoreCase("Cheque/DD"))
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from land_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
				else
				{
				qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.PAYMENTID,pp.ADVTPRICE+' '+pp.CURRENCYTYPE from land_for_lease_rent p, payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYID='"+pid+"' and p1.PAYMENTID='"+payid+"' and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				}
			}

			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

  public int deleteMember(String mid)
  {
        int count=0;
        try
        {
				String qry= "delete from register where ID='"+mid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
        }
        catch(Exception exception) { }
        return count;
  }
  public int deletePosting(String pid,String tablename)
  {
        int count=0;
        try
        {
				String qry= "delete from property where PROPERTYID='"+pid+"'";
				System.out.println("ASSET QRY >>"+qry);
				count= dbm.insertUpdateDeleteRecord(qry);
				int i=dbm.insertUpdateDeleteRecord("delete from payment where PROPERTYID='"+pid+"'");

				////--------------
				if(tablename.equals("home_for_sale"))
				{
				qry= "delete from home_for_sale where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("land_for_sale"))
				{
				qry= "delete from land_for_sale where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("apartment_for_sale"))
				{
				qry= "delete from apartment_for_sale where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("business_property_for_sale"))
				{
				qry= "delete from business_property_for_sale where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
				qry= "delete from apartment_for_lease_rent where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
				qry= "delete from business_property_for_lease_rent where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
				qry= "delete from home_for_lease_rent where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
				qry= "delete from land_for_lease_rent where PROPERTYID='"+pid+"'";
				int j=dbm.insertUpdateDeleteRecord(qry);
				}
				////--------------
        }
        catch(Exception exception) { }
        return count;
  }

  public int updateInfo(String regid,String myname,String familyname)
  {
        int count=0;
        try
        {
            String qry="update register set MYNAME='"+myname+"', FAMILYNAME='"+familyname+"' where ID='"+regid+"'";
            System.out.println("changePWD QRY >>"+qry);
            count= dbm.insertUpdateDeleteRecord(qry);

        }
        catch(Exception exception) { }
        return count;
    }
    public int changePWD(String email,String pwd,String npwd)
    {
        int count=0;
        try
        {
            String qry= "select ID,LOGINEMAILADDRESS from register where LOGINEMAILADDRESS='"+email+"' and USERPWD='"+pwd+"'";
            if(dbm.existData(qry))
            {
            qry="update register set USERPWD='"+npwd+"' where LOGINEMAILADDRESS='"+email+"' and USERPWD='"+pwd+"'";
            System.out.println("changePWD QRY >>"+qry);
            count= dbm.insertUpdateDeleteRecord(qry);
			}
        }
        catch(Exception exception) { }
        return count;
    }



public int moveExpire()
{
	int count=0;
	try
	{

       com.hybridshore.asset.common.util.Resource sampleConfig =  com.hybridshore.asset.common.util.Resource.getSampleConfig();
       int warn=7;
       String alert= sampleConfig.getString("ALERT");
       if(alert!=null)
       {
		   try{
		   warn=Integer.parseInt(alert);
	   	   }catch(Exception ex){warn=7;}
	   }
	   int awarn=warn+1;

		java.util.Vector tableVec=new java.util.Vector();
		tableVec.addElement("home_for_sale");
		tableVec.addElement("land_for_sale");
		tableVec.addElement("apartment_for_sale");
		tableVec.addElement("business_property_for_sale");
		tableVec.addElement("apartment_for_lease_rent");
		tableVec.addElement("business_property_for_lease_rent");
		tableVec.addElement("home_for_lease_rent");
		tableVec.addElement("land_for_lease_rent");
		for(int z=0;z<tableVec.size();z++)
		{
			ArrayList all_list=new ArrayList();
			String qry= "select p.PROPERTYID,d.DESCRIPTION from "+tableVec.elementAt(z).toString()+" p,postingdays d  where p.DAY_ID=d.DAY_ID and p.PROPERTYSTATUS='A'";
			all_list=dbm.getRecords(qry);
			for(int i1=0;i1<all_list.size();i1++)
			{
				ArrayList arr1=(ArrayList)all_list.get(i1);
				String propsid=arr1.get(0).toString();
				String days=arr1.get(1).toString();


////////////----------- MAIL COMPOSING HERE
							System.out.println("TOTAL DAYS>>"+days);
							int days_int=Integer.parseInt(days);
							if(days_int>awarn)
							{days_int=days_int-warn;}
							System.out.println("WARNING DAYS>>"+days_int);
							ComposeMail cmail=null;
							qry= "select p.PROPERTYID,p.CONTACTPERSON,p.CONTACTEMAILADDRESS,DATEDIFF(CURDATE(),p.ACTIVEDATE) from "+tableVec.elementAt(z).toString()+" p,payment p1  where DATE_SUB(CURDATE(),INTERVAL "+days_int+" DAY) >= p.ACTIVEDATE and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+propsid+"'";
							System.out.println("Qry>>"+qry);
							ArrayList dlist=dbm.getRecords(qry);
							for(int i11=0;i11<dlist.size();i11++)
							{
								 ArrayList arrt=(ArrayList)dlist.get(i11);
								 String id1=arrt.get(0).toString();
								 String id2=arrt.get(1).toString();
								 String to=arrt.get(2).toString();
								 String diff=arrt.get(3).toString();
								 if(Integer.parseInt(diff)>Integer.parseInt(days))
								 {
									  cmail=new ComposeMail();
									  String msg="Hi "+id2+", Your Posting is DEACTIVATED. Your PropertyID is PID_"+id1+".";
									  System.out.println("INSIDE MAIL>>>>");
									  System.out.println("MSG>>>"+msg);
									  cmail.sendMail_FromAdmin("Your Posting is DEACTIVATED",msg,to);
								 }
								 else
								 {
									 System.out.println("DATE DIFF DAYS>>"+diff);
									 int diff_int=Integer.parseInt(diff)-days_int;
									 System.out.println("SUBTRACT DATE DIFF DAYS>>"+diff_int);
									 if(diff_int<=warn && diff_int>=0)
									 {
									  diff_int=warn-diff_int;
									  cmail=new ComposeMail();
									  String msg="Hi "+id2+", After "+diff_int+" days, Your Posting will be DEACTIVATE. Your PropertyID is PID_"+id1+".";
									  System.out.println("INSIDE MAIL>>>>");
									  System.out.println("MSG>>>"+msg);
									  cmail.sendMail_FromAdmin("Your Posting will DEACTIVATE",msg,to);
									 }
								 }
							}
							cmail=null;

//////////////////// END MAIL PROCESS


			ArrayList record_list=new ArrayList();
			qry= "update "+tableVec.elementAt(z).toString()+" set PROPERTYSTATUS='E' where DATE_SUB(CURDATE(),INTERVAL "+days+" DAY) >= ACTIVEDATE  and PROPERTYID='"+propsid+"'";
			System.out.println("EXP QRY>>"+qry);
			int j= dbm.insertUpdateDeleteRecord(qry);
			count+=j;
	       }
  	   }
  	   tableVec=null;
	   System.out.println("EXPIRED move COUNT>>>"+count);

    }
	catch(Exception ex){System.out.println("EXPIRED EXCEPTION>>>"+ex.getMessage());}
	return count;
}



    public ArrayList getPostingPrices()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select PRICE_ID,ADVTPRICE,PAYMENTMETHOD,CURRENCYTYPE,MODE,ACTIVE_FLAG from postingprice where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getPostingPrice(String id)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select PRICE_ID,ADVTPRICE,PAYMENTMETHOD,CURRENCYTYPE,MODE,ACTIVE_FLAG from postingprice where ACTIVE_FLAG='A' and PRICE_ID='"+id+"'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getPostingDays()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select DAY_ID,DESCRIPTION,ACTIVE_FLAG from postingdays where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getPropertyType()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select PROPERTYTYPE_ID,DESCRIPTION,ACTIVE_FLAG,PROPERTY_TABLE from propertytype where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getCardType()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select CARDTYPE_ID,DESCRIPTION,ACTIVE_FLAG from cardtype where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}
    public ArrayList getSellerType()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select SELLERTYPE_ID,DESCRIPTION,ACTIVE_FLAG from sellertype where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getMapState(String query)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select STATE_ID,DESCRIPTION,ACTIVE_FLAG from state where ACTIVE_FLAG='A'"+query;
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getNews()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select NEWS_ID,DESCRIPTION,ACTIVE_FLAG from news where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getStates()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select STATE_ID,DESCRIPTION,ACTIVE_FLAG from state where ACTIVE_FLAG='A'";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getInfoDetails(String propid,String tablename)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry="";
            if(tablename.equals("home_for_sale"))
            {
            qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS from home_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT from land_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS from apartment_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE from business_property_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from apartment_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE,a.LEASEPERIOD,a.DEPOSITAMOUNT from business_property_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from home_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.LEASEPERIOD,a.DEPOSITAMOUNT from land_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}



    public ArrayList getPropertyType_All()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select PROPERTYTYPE_ID,DESCRIPTION,ACTIVE_FLAG,PROPERTY_TABLE from propertytype";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getSellerType_All()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select SELLERTYPE_ID,DESCRIPTION,ACTIVE_FLAG from sellertype";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getStates_All()
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry= "select STATE_ID,DESCRIPTION,ACTIVE_FLAG from state";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getPostingImage(String propid,String tablename)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
            if(tablename.equals("home_for_sale"))
            {
			qry= "select p.PROPERTYID,p.ATTACHIMAGE from home_for_sale p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "select p.PROPERTYID,p.ATTACHIMAGE from land_for_sale p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from apartment_for_sale p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from business_property_for_sale p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from apartment_for_lease_rent p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from business_property_for_lease_rent p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from home_for_lease_rent p where  p.PROPERTYID='"+propid+"'";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,p.ATTACHIMAGE from land_for_lease_rent p where  p.PROPERTYID='"+propid+"'";
			}
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

	public ArrayList getQuickSearch(String query,String tablename)
	{
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
            if(tablename.equals("home_for_sale"))
            {
            qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS from home_for_sale a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT from land_for_sale a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS from apartment_for_sale a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE from business_property_for_sale a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from apartment_for_lease_rent a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE,a.LEASEPERIOD,a.DEPOSITAMOUNT from business_property_for_lease_rent a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from home_for_lease_rent a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.LEASEPERIOD,a.DEPOSITAMOUNT from land_for_lease_rent a,property main,propertytype b,sellertype c,state d where main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			}
			// old qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,p.APPROXSQFT,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE from property p,propertytype b,sellertype c,state d where  a.PROPERTYSTATUS='A' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID"+query+" order by a.ACTIVEDATE DESC";
			System.out.println("QUICK SEARCH>>"+qry);
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

	public ArrayList getQuickSearch(String query)
	{
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
			//qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,p.PROPERTYTYPE,p.APPROXSQFT,p.SELLERTYPE,p.LOCATIONDETAILS,p.CONTACTPERSON,p.MYNAME,p.FAMILYNAME,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,p.STATE,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.PROPERTYLANDMARK,p.PROPERTYDESC,p.PRICETYPE,p.DATECREATED,p.ACTIVEDATE from property p where  p.PROPERTYSTATUS='A' and "+query+" order by p.ACTIVEDATE DESC";
			qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,p.APPROXSQFT,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE from property p,propertytype b,sellertype c,state d where  p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID"+query+" order by p.ACTIVEDATE DESC";
			System.out.println("QUICK SEARCH>>"+qry);
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

	public ArrayList getProperties(String category,String from, String to,String tablename)
	{
		ArrayList record_list=null;
		try
		{
			java.util.StringTokenizer fromStr=new java.util.StringTokenizer(from,"/");
			String s=fromStr.nextToken();
			String s1=fromStr.nextToken();
			String s2=fromStr.nextToken();
			from=s2+"-"+s1+"-"+s+" 00:00:00";
			java.util.StringTokenizer toStr=new java.util.StringTokenizer(to,"/");
			s=toStr.nextToken();
			s1=toStr.nextToken();
			s2=toStr.nextToken();
			to=s2+"-"+s1+"-"+s+" 23:59:59";

            record_list=new ArrayList();
			String qry=null;
			if(tablename.equals("home_for_sale"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from home_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from home_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("land_for_sale"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from land_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from land_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("apartment_for_sale"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from apartment_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from apartment_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("business_property_for_sale"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from business_property_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from business_property_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from apartment_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from apartment_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from business_property_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from business_property_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from home_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from home_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from land_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList firstArr=dbm.getRecords(qry);
				qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT from land_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where p.PROPERTYSTATUS='"+category+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.DATECREATED>='"+from+"' and  p.DATECREATED<='"+to+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
				System.out.println("PROPERTIES LIST>>"+qry);
				ArrayList secondArr=dbm.getRecords(qry);
				for(int i=0;i<firstArr.size();i++)
				{
					 record_list.add((ArrayList)firstArr.get(i));
				}
				for(int i1=0;i1<secondArr.size();i1++)
				{
					 record_list.add((ArrayList)secondArr.get(i1));
				}
			}

		}
		catch(Exception ex){}
		return record_list;
	}



		public ArrayList getProperties(String pid,String tablename)
		{
			ArrayList record_list=null;
			try
			{

	            record_list=new ArrayList();
				String qry=null;
				if(tablename.equals("home_for_sale"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from home_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from home_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("land_for_sale"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from land_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from land_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("apartment_for_sale"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from apartment_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from apartment_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("business_property_for_sale"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from business_property_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from business_property_for_sale p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from apartment_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from apartment_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from business_property_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from business_property_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from home_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from home_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,e.DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from land_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp,cardtype e where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID=e.CARDTYPE_ID and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList firstArr=dbm.getRecords(qry);
					qry= "select p.PROPERTYID,b.DESCRIPTION,c.DESCRIPTION,p.CONTACTPERSON,p.ADDRESSLINE1,p.CITY,d.DESCRIPTION,p.PHONE1,p.ATTACHIMAGE,p.PROPERTYPRICE,p.CONTACTEMAILADDRESS,p.DATECREATED,pp.PAYMENTMETHOD,'Cheque/DD' as DESCRIPTION,p1.CREDITCARDNUM,p1.MONTHEXPIRATION,p1.YEAREXPIRATION,p.NOPROPERTYPRICE,p1.NAMEONCARD,p1.CVV2NUMBER,p1.TOLLFREENUM,p1.DATECREATED,p1.PAYMENTID,pp.CURRENCYTYPE,p.PRICESQFT,p.PROPERTYSTATUS from land_for_lease_rent p,property main,payment p1,propertytype b,sellertype c,state d,postingprice pp where main.PROPERTYID=p.PROPERTYID and p.PROPERTYID=p1.PROPERTYID and p.PROPERTYID='"+pid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p1.CARDTYPE_ID='0' and p1.PRICE_ID=pp.PRICE_ID order by p.DATECREATED DESC";
					System.out.println("PROPERTIES LIST>>"+qry);
					ArrayList secondArr=dbm.getRecords(qry);
					for(int i=0;i<firstArr.size();i++)
					{
						 record_list.add((ArrayList)firstArr.get(i));
					}
					for(int i1=0;i1<secondArr.size();i1++)
					{
						 record_list.add((ArrayList)secondArr.get(i1));
					}
				}

			}
			catch(Exception ex){}
			return record_list;
	}

	public ArrayList getMembers(String from, String to)
	{
		ArrayList record_list=null;
		try
		{
			java.util.StringTokenizer fromStr=new java.util.StringTokenizer(from,"/");
			String s=fromStr.nextToken();
			String s1=fromStr.nextToken();
			String s2=fromStr.nextToken();
			from=s2+"-"+s1+"-"+s+" 00:00:00";
			java.util.StringTokenizer toStr=new java.util.StringTokenizer(to,"/");
			s=toStr.nextToken();
			s1=toStr.nextToken();
			s2=toStr.nextToken();
			to=s2+"-"+s1+"-"+s+" 23:59:59";

            record_list=new ArrayList();
            String qry=null;
			qry= "select ID,LOGINEMAILADDRESS,MYNAME,FAMILYNAME,DATECREATED from register where DATECREATED>='"+from+"' and  DATECREATED<='"+to+"' order by DATECREATED DESC";
			System.out.println("MEMBERS LIST>>"+qry);
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}

    public ArrayList getPostingNew(String propid,String tablename)  // getPosting(String propid)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
            if(tablename.equals("home_for_sale"))
            {
            qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS from home_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("land_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT from land_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("apartment_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS from apartment_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("business_property_for_sale"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE from business_property_for_sale a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("apartment_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APARTMENTAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from apartment_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("business_property_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.BUSINESSPROPERTY_AREA,a.BUILDINGAGE,a.LEASEPERIOD,a.DEPOSITAMOUNT from business_property_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("home_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.BUILDINGAREA,a.BUILDINGAGE,a.BEDROOMS,a.LEASEPERIOD,a.DEPOSITAMOUNT from home_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			else if(tablename.equals("land_for_lease_rent"))
			{
			qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PRICESQFT,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE,a.APPROXSIZE,a.APPROXSQFT,a.LEASEPERIOD,a.DEPOSITAMOUNT from land_for_lease_rent a,property main,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and main.PROPERTYID=a.PROPERTYID and a.PROPERTYSTATUS<>'E' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
            // old qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.DATECREATED,a.ACTIVEDATE from property a,propertytype b,sellertype c,state d where a.PROPERTYID='"+propid+"' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}
    public ArrayList getPosting(String userid,String category,String ptype,String tablename)  //getPosting(String userid,String category)
    {
		ArrayList record_list=null;
		try
		{
            record_list=new ArrayList();
            String qry=null;
            if(category.equals("A"))
            {
				if(tablename.equals("home_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS from home_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT from land_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS from apartment_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE from business_property_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from apartment_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE,p.LEASEPERIOD,p.DEPOSITAMOUNT from business_property_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from home_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.LEASEPERIOD,p.DEPOSITAMOUNT from land_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='A' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}

				//qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,p.APPROXSQFT,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE from property p,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and p.PROPERTYSTATUS='A' and p.PROPERTYID=pt.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
			}
			else if(category.equals("D"))
            {
				if(tablename.equals("home_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS from home_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT from land_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS from apartment_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE from business_property_for_sale p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from apartment_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE,p.LEASEPERIOD,p.DEPOSITAMOUNT from business_property_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from home_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.LEASEPERIOD,p.DEPOSITAMOUNT from land_for_lease_rent p,property main,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and main.PROPERTYID=pt.PROPERTYID and p.PROPERTYSTATUS='D' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				//qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,p.APPROXSQFT,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE from property p,payment pt,propertytype b,sellertype c,state d where p.ID='"+userid+"' and p.PROPERTYSTATUS='D' and p.PROPERTYID=pt.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
			}
			else if(category.equals("P"))
            {
				if(tablename.equals("home_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS from home_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT from land_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS from apartment_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE from business_property_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from apartment_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE,p.LEASEPERIOD,p.DEPOSITAMOUNT from business_property_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from home_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.LEASEPERIOD,p.DEPOSITAMOUNT from land_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID  and p.PROPERTYID not in (select PROPERTYID from payment) order by p.ACTIVEDATE DESC";
				}
				//qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,p.APPROXSQFT,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE from property p,propertytype b,sellertype c,state d where p.ID='"+userid+"' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID and p.PROPERTYID not in (select PROPERTYID from payment)  order by p.ACTIVEDATE DESC";
			}
			else
			{
				if(tablename.equals("home_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS from home_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT from land_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS from apartment_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_sale"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE from business_property_for_sale p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("apartment_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APARTMENTAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from apartment_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("business_property_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.BUSINESSPROPERTY_AREA,p.BUILDINGAGE,p.LEASEPERIOD,p.DEPOSITAMOUNT from business_property_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("home_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.BUILDINGAREA,p.BUILDINGAGE,p.BEDROOMS,p.LEASEPERIOD,p.DEPOSITAMOUNT from home_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				else if(tablename.equals("land_for_lease_rent"))
				{
				qry= "select p.PROPERTYID,p.ID,p.PROPERTYSTATUS,b.DESCRIPTION,c.DESCRIPTION,p.LOCATIONDETAILS,p.CONTACTPERSON,p.ADDRESSLINE1,p.ADDRESSLINE2,p.ADDRESSLINE3,p.CITY,d.DESCRIPTION,p.PINCODE,p.PHONE1,p.PHONE2,p.PHONE3,p.CONTACTEMAILADDRESS,p.ATTACHIMAGE,p.PRICESQFT,p.PROPERTYPRICE,p.NOPROPERTYPRICE,p.PROPERTYDESC,p.DATECREATED,p.ACTIVEDATE,p.APPROXSIZE,p.APPROXSQFT,p.LEASEPERIOD,p.DEPOSITAMOUNT from land_for_lease_rent p,property main,propertytype b,sellertype c,state d where p.ID='"+userid+"' and main.PROPERTYID=p.PROPERTYID and p.PROPERTYSTATUS='E' and p.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and p.SELLERTYPE_ID=c.SELLERTYPE_ID and p.STATE_ID=d.STATE_ID order by p.ACTIVEDATE DESC";
				}
				//qry= "select a.PROPERTYID,a.ID,a.PROPERTYSTATUS,b.DESCRIPTION,a.APPROXSQFT,c.DESCRIPTION,a.LOCATIONDETAILS,a.CONTACTPERSON,a.ADDRESSLINE1,a.ADDRESSLINE2,a.ADDRESSLINE3,a.CITY,d.DESCRIPTION,a.PINCODE,a.PHONE1,a.PHONE2,a.PHONE3,a.CONTACTEMAILADDRESS,a.ATTACHIMAGE,a.PROPERTYPRICE,a.NOPROPERTYPRICE,a.PROPERTYDESC,a.ACTIVEDATE,a.ACTIVEDATE from expiredposting p,propertytype b,sellertype c,state d where a.ID='"+userid+"' and a.PROPERTYTYPE_ID=b.PROPERTYTYPE_ID and a.SELLERTYPE_ID=c.SELLERTYPE_ID and a.STATE_ID=d.STATE_ID";
			}
			record_list=dbm.getRecords(qry);
		}
		catch(Exception ex){}
		return record_list;
	}



    DataBaseMediator dbm;
}

