// AUTHOR : K. SIVAKUMAR & Annan
// Decompiler options: packimports(3)
// Source File Name:   QueryBean.java

package com.hybridshore.asset.web;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class ComposeMail
{

    public ComposeMail()
    {}

	public void sendMail_ToAdmin(String subject,String msg)
	{
		try
		{

            com.hybridshore.asset.common.util.Resource sampleConfig =  com.hybridshore.asset.common.util.Resource.getSampleConfig();
            String host= sampleConfig.getString("SMTPHOST");
            String from= sampleConfig.getString("FROM");
            String to= sampleConfig.getString("FROM");
            java.util.StringTokenizer str=new java.util.StringTokenizer(to,",");
            java.util.Vector toVec=new java.util.Vector();
            while(str.hasMoreTokens())
            {
				toVec.addElement(str.nextToken());
			}

			// Get system properties
			java.util.Properties props = System.getProperties();

			// Setup mail server
			props.put("mail.smtp.host", host);

			// Get session
			javax.mail.Session session1 = Session.getDefaultInstance(props, null);

			// Define message
			MimeMessage message = new MimeMessage(session1);
			//message.setContentType("text/html");


			message.setFrom(new InternetAddress(from));

			/*message.addRecipient(Message.RecipientType.TO,
			  new InternetAddress(to));
			  */
			  InternetAddress[] addressTo = new InternetAddress[toVec.size()];
			  for (int i = 0; i < toVec.size(); i++)
			  {
				  addressTo[ i ] = new InternetAddress(toVec.elementAt(i).toString());
			  }
			  message.setRecipients(Message.RecipientType.TO, addressTo);




			message.setSubject(subject);
			message.setSentDate(new java.util.Date());
			message.setText(msg);

			// Send message
	Transport.send(message);

	 //Transport transport = session1.getTransport("smtp");
	 //transport.connect(host, "", "");
	 //transport.send(message);



		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			//System.out.println(">>"+ex.getMessage());
	   }

	}

	public void sendMail_FromAdmin(String subject,String msg,String to)
	{
		try
		{

            com.hybridshore.asset.common.util.Resource sampleConfig =  com.hybridshore.asset.common.util.Resource.getSampleConfig();
            String host= sampleConfig.getString("SMTPHOST");
            String from= sampleConfig.getString("FROM");

            java.util.Vector toVec=new java.util.Vector();
			toVec.addElement(to);

			// Get system properties
			java.util.Properties props = System.getProperties();

			// Setup mail server
			props.put("mail.smtp.host", host);

			// Get session
			javax.mail.Session session1 = Session.getDefaultInstance(props, null);

			// Define message
			MimeMessage message = new MimeMessage(session1);

			message.setFrom(new InternetAddress(from));

			/*message.addRecipient(Message.RecipientType.TO,
			  new InternetAddress(to));
			  */
			  InternetAddress[] addressTo = new InternetAddress[toVec.size()];
			  for (int i = 0; i < toVec.size(); i++)
			  {
				  addressTo[ i ] = new InternetAddress(toVec.elementAt(i).toString());
			  }
			  message.setRecipients(Message.RecipientType.TO, addressTo);




			message.setSubject(subject);
			message.setSentDate(new java.util.Date());
			message.setText(msg);

			// Send message
	Transport.send(message);

	 //Transport transport = session1.getTransport("smtp");
	 //transport.connect(host, "", "");
	 //transport.send(message);



		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			//System.out.println(">>"+ex.getMessage());
	   }

	}




		public void sendMail_FromAdmin_HTML(String subject,String msg,String to)
		{
			try
			{

	            com.hybridshore.asset.common.util.Resource sampleConfig =  com.hybridshore.asset.common.util.Resource.getSampleConfig();
	            String host= sampleConfig.getString("SMTPHOST");
	            String from= sampleConfig.getString("FROM");

	            java.util.Vector toVec=new java.util.Vector();
				toVec.addElement(to);

				// Get system properties
				java.util.Properties props = System.getProperties();

				// Setup mail server
				props.put("mail.smtp.host", host);

				// Get session
				javax.mail.Session session1 = Session.getDefaultInstance(props, null);

				// Define message
				MimeMessage message = new MimeMessage(session1);
			    //message.setContentType("text/html");

				message.setFrom(new InternetAddress(from));

				/*message.addRecipient(Message.RecipientType.TO,
				  new InternetAddress(to));
				  */
				  InternetAddress[] addressTo = new InternetAddress[toVec.size()];
				  for (int i = 0; i < toVec.size(); i++)
				  {
					  addressTo[ i ] = new InternetAddress(toVec.elementAt(i).toString());
				  }
				  message.setRecipients(Message.RecipientType.TO, addressTo);




				message.setSubject(subject);
				message.setSentDate(new java.util.Date());
				message.setText(msg);

				// Send message
		Transport.send(message);

		 //Transport transport = session1.getTransport("smtp");
		 //transport.connect(host, "", "");
		 //transport.send(message);



			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				//System.out.println(">>"+ex.getMessage());
		   }

	}



}

