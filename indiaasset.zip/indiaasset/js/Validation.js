var radio_buttonname = new Array();

function checkForEmpty(frm,serverdate)
{
   loop: for(var i=0;i<frm.elements.length;i++)
   {

    if(frm.elements[i].getAttribute("id") != "option" & frm.elements[i].getAttribute("format") != "hidden")
    {
      switch(frm.elements[i].type)
      {
         case "text":
         {
         	if(frm.elements[i].value == "" && frm.elements[i].disabled == false)
         	{
         	   if(frm.elements[i].getAttribute("validate") == null)
         	   {
         	   	alert("Empty "+frm.elements[i].name+" is not allowed");
         	   }
         	   else
         	   {
         	   	alert("Empty "+frm.elements[i].getAttribute("validate")+" is not allowed");
         	   }
         	   frm.elements[i].focus();
		   	return false;
         	}
         	else
         	{
         		if(frm.elements[i].getAttribute("format") == "email")
         		{
         		   var val = frm.elements[i].value;
         		   var setFlag = false;

         		   for(var j=0;j<val.length;j++)
         		   {
         		    	if(val.charAt(j) != "@")
         		    	{
         		   	    setFlag = true;
         		   	}
			   	else
			   	{
			   	    setFlag = false;
			   	    break;
			   	}
			   }

			   if(setFlag)
			   {
				alert("'@' symbol is missing in your address");
         		   	frm.elements[i].focus();
			   	return false;
			   }

         		}
         	}
           break;
	}
        case "password":
        {
         	if(frm.elements[i].value == "")
         	{
         	   if(frm.elements[i].getAttribute("validate") == null)
         	   {
         	   	alert("Empty "+frm.elements[i].name+" is not allowed");
         	   }
         	   else
         	   {
         	   	alert("Empty "+frm.elements[i].getAttribute("validate")+" is not allowed");
         	   }
         	   frm.elements[i].focus();
		   return false;
         	}
           break;
	}
        case "select-one":
        case "select":
        {
         	if(frm.elements[i].options[0].selected == true && frm.elements[i].options[0].text.substring(0,6) == "Select")
         	{
         	   if(frm.elements[i].getAttribute("validate") == null)
         	   {
         	   	alert(frm.elements[i].name+" is not yet selected");
         	   }
         	   else
         	   {
         	   	alert(frm.elements[i].getAttribute("validate")+" is not yet selected");
         	   }
         	   frm.elements[i].focus();
		   return false;
         	}
           break;
	}
        case "file":
        case "textarea":
        {
         	if(frm.elements[i].value == "")
         	{
         	   if(frm.elements[i].getAttribute("validate") == null)
         	   {
         	   	alert("Empty "+frm.elements[i].name+" is not allowed");
         	   }
         	   else
         	   {
         	   	alert("Empty "+frm.elements[i].getAttribute("validate")+" is not allowed");
         	   }
         	   frm.elements[i].focus();

		   return false;
         	}
           break;
	}
        case "checkbox":
        {
         	if(frm.elements[i].checked == false)
         	{
         	   if(frm.elements[i].getAttribute("validate") == null)
         	   {
         	   	alert("Empty "+frm.elements[i].name+" is not allowed");
         	   }
         	   else
         	   {
         	   	alert("Empty "+frm.elements[i].getAttribute("validate")+" is not allowed");
         	   }
         	   frm.elements[i].focus();
         	   return false;
         	}
           break;
	}
	case "radio":
	{
	     var iVal = i;
	     var radioStatus = false;

		if(frm.elements[i].getAttribute("format") != null)
		{
         		for(var rad = 0;rad < frm.elements[i].getAttribute("format");rad++)
         		{

         		   if(frm.elements[parseInt(i)+parseInt(rad)].checked)
         		   {
         		     radioStatus = true;
         		     i = parseInt(iVal - 1) + parseInt(frm.elements[i].getAttribute("format"));
         		     break;
         		   }
          		}

                	if(!radioStatus)
                	{
			   if(frm.elements[i].getAttribute("validate") == null)
			   {
				alert(frm.elements[i].name+" is not selected");
			   }
			   else
			   {
				alert(frm.elements[i].getAttribute("validate")+" is not selected");
			   }
         		   	frm.elements[iVal].focus();
         		   	i = iVal;
         		   	return false;
			}
		}
	break;
	}



      }

   }
   }

   //if(!checkForRadio(frm))
   //   return false;

   return true;
}
//validaion for start with blank space
var sString = "";
function isStartWithWhiteSpace(sStringval)
{
   sString = sStringval.value;
   if (sString != "")
   {
      var iStart = 0;
      var iEnd = sString.length - 1;
      var sWhitespace = " \t\f\n\r\v";

      while (sWhitespace.indexOf(sString.charAt(iStart)) != -1)
      {
         iStart++;
         if (iStart > iEnd)
            break;
      }
		if(iStart==0)
			return true;
      	else
      		alert("Don't start with empty space[s]");
      		sStringval.focus();
      		return false;
     }
}
//validateion for only blank space
function isBlankSpace(strval)
{
	pattern = strval;
		if(pattern.search(/^\s+/i )!=-1) {
		alert("You have a blank box"); return false;
		}
}
//characters count...
//<textarea name="commitee_purpose" cols="70" rows="4" class="tabledivision" onKeyDown="textCounter(document.formname.commitee_purpose,document.formname.remLen2,2000)"
//onKeyUp="textCounter(document.formname.commitee_purpose,document.formname.remLen2,2000)"></textarea>
//<br><input readonly type="text" name="remLen2" class=tabledivision size="2" maxlength="3" value="2000"><font color=red>&nbsp;Characters left</font>

function textCounter(field,cntfield,maxlimit)
{
	if (field.value.length > maxlimit) // if too long...trim it!
		field.value = field.value.substring(0, maxlimit);
	// otherwise, update 'characters left' counter
	else
		cntfield.value = maxlimit - field.value.length;
}

function clear(form)
    {
     eval("document."+form+".reset()");
    }


function numeric_Validation(fields,fieldName)
{
       flag=true;
       field=fields.value;
       var num=parseInt(field.length);
           if(num==0 )
              {
               alert(fieldName+":"+'cannot be Empty');
               fields.focus();
               flag=false;
               }
            else
               {
                 //checking starting field
			 startVal=field.charAt(0);

			if( !( (startVal>="0") && (startVal<="9") || (startVal=="\.")) )
			 {
				  alert("SpecialCharacter not allowed in the starting of "+ fieldName);
				  fields.focus();
				  flag=false;

			  }
                     else
                        {
				for(var i=0;i<num;++i)
				 {
				      var str=field.substring(i,i+1);
				     if( !((str>="0") && (str<="9") ||  (str=="\.")) )
					 {
					   alert(fieldName+":"+'Invalid entry! only number allowed');
					   fields.focus();
					   flag= false;
					   break;

					   }
				  }//end of for
		      }//end of else

              }//end of else

         return flag;
      }
var alpha_alerted = false;

function alpha_Validation(fields,fieldName)
{
   flag=true;
   field=fields.value;

   var num=parseInt(field.length);
   if(num==0)
   {
        alert(fieldName+":"+'cannot be Empty ');
        fields.focus();
        flag=false;
   }
   else
   {
   	startVal=field.charAt(0);

	if(!alpha_alerted)
	{
		if(!(  (startVal>="a" && startVal<="z")||(startVal>="A" && startVal<="Z")|| (startVal==' ')  ))
		{
		  alert("Invalid "+ fieldName);
		  alpha_alerted = true;
		  fields.focus();
		  flag=false;
		}
		else
		{
		   for(var i=1;i<num;i++)
		   {
			var str=field.charAt(i);

			if(!((str>="a" && str<="z")||(str>="A" && str<="Z")|| (str==' ')|| (str=="-")|| (str=="_")  ))
			{
				alert(fieldName+":"+'Invalid Entry! only String allowed');
				alpha_alerted = true;
				fields.focus();
				flag= false;
				break;
			}
		   }//end of for
		}//end of inner else
	}
	else
	{
		alpha_alerted = false;
		fields.select();
	}
    }//end of else
     return flag;
}


var xml_alerted = false;

function xml_Validation(fields,fieldName)
{
   flag=true;
   field=fields.value;

   var num=parseInt(field.length);
   if(num==0)
   {
        alert(fieldName+":"+'cannot be Empty ');
        fields.focus();
        flag=false;
   }
   else
   {
   	startVal=field.charAt(0);

	if(!alpha_alerted)
	{
		if(!( (startVal>="a" && startVal<="z")||(startVal>="A" && startVal<="Z")))
		{
		  alert("Invalid "+ fieldName);
		  xml_alerted = true;
		  fields.focus();
		  flag=false;
		}
		else
		{
		   for(var i=1;i<num;i++)
		   {
			var str=field.charAt(i);

			if(!((str>="a" && str<="z")||(str>="A" && str<="Z")||(str>='0' && str<='9')||(str=='-')||(str=='_')||(str==':')))
			{
				alert(fieldName+":"+'Invalid Entry! only String allowed');
				xml_alerted= true;
				fields.focus();
				flag= false;
				break;
			}
		   }//end of for
		}//end of inner else
	}
	else
	{
		xml_alerted = false;
		fields.select();
	}
    }//end of else
     return flag;
}

//alpha numeric validations the fields can contain both alpha and numeric values


function alphaNumeric_Validation(fields,fieldName)
{
   flag=true;
   field=fields.value;

     var num=parseInt(field.length);

     if(num==0)
     {
       alert(fieldName+":"+'cannot be Empty ');
       fields.focus();
       flag=false;

     }
     else
     {
	startVal=field.charAt(0);

	if(!((startVal>='a' && startVal<='z')||(startVal>='A' && startVal<='Z')|| (startVal>='0' && startVal<='9')|| (startVal=='')))
	{
	  alert("Invalid "+ fieldName+"! Only Character & Number allowed. Special Character not allowed.");
	  fields.focus();
	  flag=false;
	}
	else if(startVal == " ")
	{
	  alert("Invalid "+ fieldName+"! Only Character & Number allowed. Special Character not allowed.");
	  fields.select();
	  flag=false;
	}
	else
	{
		for(var i=1;i<num;i++)
		{
		  var str=field.charAt(i);

		  if(!((str>='a' && str<='z')||(str>='A' && str<='Z') ||(str>='0' && str<='9') || (str=='-')|| (str=='_') ))
		  {
			alert(fieldName+":"+'Invalid Entry! Only Character & Number allowed. Special Character not allowed ('+str+')');
			fields.focus();
			flag= false;
			break;
		  }
		  else if(str == "")
		  {
			alert(fieldName+":"+'Invalid Entry! Only Character & Number allowed. Special Character not allowed. ('+str+')');
			fields.focus();
			flag= false;
			break;
		  }
		}//end of for

     	}//end of inner else

     }//end of else
  return flag;
}

//userName checking that should contain an underscore





//  onKeyUp='characterCount(document.InitiateForm.message,mescount,5000)'   mecount >> Span ID name
 function characterCount(frmObj,spanID,maxCount)
 {
		 var count=frmObj.value.length;
		 maxC=parseInt(maxCount);
		 if(parseInt(spanID.innerText)<=0 && frmObj.value.length>maxC)
		 {
			 spanID.innerText=0;
			 frmObj.value=frmObj.value.substring(0,maxC-1);
		 }
		 else
		 {
			 spanID.innerText=maxC-count;
		 }

 }

function alphaNumeric_Validation1(fields,fieldName)
{
   flag=true;
   field=fields.value;

     var num=parseInt(field.length);

     if(num==0)
     {
       alert(fieldName+":"+'cannot be Empty ');
       fields.focus();
       flag=false;

     }
     else
     {
	startVal=field.charAt(0);

	if(!((startVal>='a' && startVal<='z')||(startVal>='A' && startVal<='Z')|| (startVal>='0' && startVal<='9')|| (startVal=='')))
	{
	  alert("Invalid "+ fieldName);
	  fields.focus();
	  flag=false;
	}
	else if(startVal == " ")
	{
	  alert("Invalid "+ fieldName);
	  fields.select();
	  flag=false;
	}
	else
	{
		for(var i=1;i<num;i++)
		{
		  var str=field.charAt(i);

		  if(!((str>='a' && str<='z')||(str>='A' && str<='Z') ||(str>='0' && str<='9') || (str=='-')|| (str=='_') ))
		  {
			alert(fieldName+":"+'Invalid Entry! only String allowed'+str);
			fields.focus();
			flag= false;
			break;
		  }
		  else if(str == "")
		  {
			alert(fieldName+":"+'Invalid Entry! only String allowed'+str);
			fields.focus();
			flag= false;
			break;
		  }
		}//end of for

     	}//end of inner else

     }//end of else
  return flag;
}





function userName_Validation(fields,fieldName)
{
   flag=true;
   field=fields.value;
   var num=parseInt(field.length);

   if(num==0)
   {
       	alert(fieldName+":"+'cannot be Empty ');
       	fields.focus();
       	flag=false;

   }
   else
   {
   	startVal=field.charAt(0);
	if(!(  (startVal>="a" && startVal<="z")||(startVal>="A" && startVal<="Z")|| (startVal>="0" && startVal<="9")|| (startVal==' ')  ))
	{
	  alert("Invalid "+ fieldName);
	  fields.focus();
	  flag=false;
  	}
   }//end of else
  return flag;
}

var email_alerted = false;

function email_Validation(fields,fieldName)
{
     flag=true;
     field=fields.value;
     var num=parseInt(field.length);

     if(num==0)
     {
       	alert(fieldName+":"+'cannot be Empty ');
       	fields.focus();
       	flag=false;
     }
     else
     {
     	startVal=field.charAt(0);

	ind1=field.indexOf("@");
	ind2=field.indexOf(".");
	ind=ind2-ind1;

	loop:if(!email_alerted)
	{
		if(!((startVal>='a' && startVal<='z')||(startVal>='A' && startVal<='Z')|| (startVal=='')  ))
		{
		  email_alerted = true;
		  alert("SpecialCharacter not allowed in the starting of "+ fieldName);
		  fields.focus();
		  flag=false;
		  break loop;
		}
		else if( (ind1== -1) || (ind2== -1) || (ind<=1 ) )
		{
		   email_alerted = true;
		   alert("Invalid mail address");
		   fields.focus();
        	   flag=false;
        	   break loop;
		}
		else
		{
		   for(var i=1;i<num;i++)
		   {
		  	var str=field.charAt(i);

		   	if(!((str>="a" && str<="z")||(str>="A" && str<="Z")||(str>="0" && str<="9")|| (str=='@')|| (str=='-')|| (str=='_')||(str=='\.')  ))
			{
			   email_alerted = true;
			   alert(fieldName+":"+'Invalid Entry! ');
			   fields.focus();
			   flag= false;
			   break;
			}
		   }//end of for
	         }//end of inner else
	 }
	 else
	 {
	 	email_alerted = false;
	   	fields.focus();

	 }
    }//end of else
    return flag;
}
//this for phone nos that can contain initial + and - at the middle
var phone_alerted = false;

function phoneNo_Validation(fields,fieldName)
{
       flag=true;
       field=fields.value;
       var num=parseInt(field.length);

       if(num==0 )
       {
               alert(fieldName+":"+'cannot be Empty');
               fields.focus();
               flag=false;
       }
       else
       {
                startVal=field.charAt(0);

		if(!phone_alerted)
		{
			if( !((startVal>="0") && (startVal<="9") ) )
			{
			  alert("Invalid  "+ fieldName);
			  phone_alerted = true;
			  fields.focus();
			  flag=false;
	  		}
          		else
          		{
				for(var i=1;i<num;++i)
				{
				      var str=field.substring(i,i+1);

				      if( !((str>="0") && (str<="9") || (str=='-') || (str==' ')) )
				      {
					   alert(fieldName+":"+'should only be in number');
					   phone_alerted = true;
					   fields.focus();
					   flag= false;
					   break;
				      }
				}//end of for
			}//end of else
		}
		else
		{
			fields.focus();
			phone_alerted = false;
		}

        }//end of else

    return flag;
}

//this for address that contain comma,fullstop or pincode in numbers and with a hypen
function address_Validation(fields,fieldName)
{//form value
   flag=true;
   field=fields.value;
     var num=parseInt(field.length);
     if(num==0)
     {
       alert(fieldName+":"+'cannot be Empty ');
       fields.focus();
       flag=false;

     }
     //to check the starting char is not a special character





     else
     {           startVal=field.charAt(0);
		if(!(  (startVal>="a" && startVal<="z")||(startVal>="A" && startVal<="Z")||(startVal>="0" && startVal<="9")|| (startVal==' ')  ))
		 {
			  alert("SpecialCharacter not allowed in the starting of "+ fieldName);
			  fields.focus();
			  flag=false;

		  }

		else
		  {


			for(var i=1;i<num;i++)
			{
			  var str=field.charAt(i);
			   if(!((str>="a" && str<="z")||(str>="A" && str<="Z")||(str>="0" && str<="9")|| (str==' ')|| (str=='-')|| (str=='_') || (str==',')|| (str=='/')  ))
				 {alert(fieldName+":"+" "+"invalid:"+str);
				   //alert(fieldName+":"+'Invalid Entry! only String/Number allowed');
				   fields.focus();
				   flag= false;
				   break;
				 }
			}//end of for
		   }//end of inner else

      }//end of else
     return flag;
}


//check equality of password and confirm password

function checkPassword(passVal1,passVal2)
{

  str1=passVal1.value;
  str2=passVal2.value;

	 if(str1.length<5)
	    {
	     alert("password should be more than 5 characters");
             return false;
	     }

	  else

	    {


		  if(str1==str2)
		   {

		     return true;
		    }

		    else
		      {
		     alert("password and Confirmpassword must be same");
		     document.frm.pass2.value="";
		     document.frm.pass2.focus();
		     return false;
		     }

	     }//end of else



 }//end of checkPassword

var bloodgroup_alerted = false;

function bloodGroup_Validation(fields,fieldName)
{
   flag=true;
   field=fields.value;

   var num=parseInt(field.length);
   if(num==0)
   {
       	alert(fieldName+":"+'cannot be Empty ');
       	fields.focus();
       	flag=false;
   }
   else
   {
   	startVal=field.charAt(0);

	if(!bloodgroup_alerted)
	{
		if(!(  (startVal>="a" && startVal<="z")||(startVal>="A" && startVal<="Z")|| (startVal==' ')  ))
		{
		  alert("SpecialCharacter not allowed in the starting of "+ fieldName);
		  bloodgroup_alerted = true;
		  fields.focus();
		  flag=false;
   		}
		else
		{
			for(var i=0;i<num;i++)
			{
			  var str=field.charAt(i);

			   if(!((str>="a" && str<="z")||(str>="A" && str<="Z")||(str=="-")||(str=="+")))
			   {
				   alert(fieldName+":"+'Invalid Entry!' );
				   bloodgroup_alerted = true;
				   fields.focus();
				   flag= false;
				   break;
			   }
			}//end of for
		}//end of inner else
	}
	else
	{
		bloodgroup_alerted = false;
		fields.focus();
		flag= false;
	}
    }//end of else

    return flag;
}








function missing_Fields(fields,fieldName)
 {  //form value
   field=fields.value;
   if(field=='')
     {
         alert(fieldName+":"+'Missed');
         fields.focus();
         return false;
     }

     return true;
 }


var startDate,endDate;
var startDay,endDay;
var startMonth,endMonth;
var startYear,endYear;

function dateValid(start,end)
{
     if(start!='' && end!='')
     {
		startDate=start;
		endDate=end;

		startDay=startDate.substring(0,2);
		startMonth=parseInt(getMonthNum(startDate.substring(3,6)));
		startYear=parseInt(startDate.substring(7,11));

		endDay=endDate.substring(0,2);
		endMonth=parseInt(getMonthNum(endDate.substring(3,6)));
		endYear=parseInt(endDate.substring(7,11));

		if(endYear==startYear)
		{
			if(endMonth==startMonth)
				{
				if(endDay<startDay)
				   {
				      alert('Invalid Date Selection');
				   }
				}
			else
				{
				if(endMonth<startMonth)
				   {
				        alert('Invalid Date Selection');
				   }
				}
		}
		else if(endYear<startYear)
		{
		      alert('Invalid Date Selection');
		      document.all.CALENDAR.style.visibility='visible';
		}
 	}
}


function check_ForParticularElements()
{
   var no_of_arguments = arguments.length;

   if(parseInt(no_of_arguments % 2) == 0)
   {
   	for(var i=0;i<no_of_arguments;i++)
   	{
   	   inc = i + 1;
   	   if(!arguments[i].disabled)
   	   {
   	   	switch(arguments[inc])
   	   	{
   	       case "text":
   	       case "textarea":
   	       case "password":
   	       {
   	          if(arguments[i].value.length > 7999){
				  alert("Text description is greater than the allocation. Can't be updated.");
				  return false;
			  }

   	          if(arguments[i].value == "")
   	          {
		      	if(arguments[i].getAttribute("validate") == null)
		      	{
					alert("Empty "+arguments[i].name+" is not allowed");
		    	}
		      	else
		      	{
			 		alert("Empty "+arguments[i].getAttribute("validate")+" is not allowed");
		      	}
   	          	arguments[i].focus();
   	          	return false;
   	          }
   	          else
   	          {
				var characters_setted = false;

				for(var kk=0;kk<arguments[i].value.length;kk++)
				{
					if((arguments[i].value.charAt(kk) != "" & arguments[i].value.charAt(kk) != " "))
					{
						characters_setted = true;
					}
				}

				if(!characters_setted)
				{
					if(arguments[i].getAttribute("validate") == null)
					{
						alert("Empty "+arguments[i].name+" is not allowed");
					}
					else
					{
						alert("Empty "+arguments[i].getAttribute("validate")+" is not allowed");
					}
					arguments[i].value = "";
					arguments[i].focus();

					return false;
				}
   	          }

   	          break;
   	       }
   	       case "select":
   	       {
   	          if(arguments[i].options[0].selected)
   	          {
		      if(arguments[i].getAttribute("validate") == null)
		      {
					alert(arguments[i].name+" is not yet selected");
		      }
		      else
		      {
					alert(arguments[i].getAttribute("validate")+" is not yet selected");
		      }
   	              arguments[i].focus();
   	              return false;
   	          }
   	          break;
   	       }
   	       case "radio":
   	       {
   	          var setFlag = false;

   	          for(var j=0;j<arguments[i].length;j++)
   	          {
   	            if(arguments[i][j].checked)
   	            {
			setFlag = true;
			break;
   	            }
   	            else
   	            {
   	                setFlag = false;
   	            }
   	          }

   	          if(!setFlag)
   	          {
		      if(arguments[i][0].getAttribute("validate") == null)
		      {
			alert("Empty "+arguments[i][0].name+" is not checked");
		      }
		      else
		      {
			 alert("Empty "+arguments[i][0].getAttribute("validate")+" is not checked");
		      }
   	              arguments[i][0].focus();
   	              return false;
   	          }
   	          break;
   	       }
   	   	}
   	   	++i;
   	   }
   	}
   }
   return true;
}


// d - accepts only digits
// w - accepts both digits and letters
// W - accepts only special characters

var numeric_alert = false;

function check_NumericData(obj)
{
   var regexp = /\d/;

   if(!numeric_alert)
   {
    for(var i=0;i<obj.value.length;i++)
    {
        if(!regexp.test(obj.value.charAt(i)))
        {
           alert(obj.name+" : should only be in numbers");
           numeric_alert = true;
           obj.select();
           obj.focus();
           return false;
        }
    }
   }
   else
   {
     numeric_alert = false;
     obj.select();
     obj.focus();
     return false;
   }
    return true;
}

var alpha_numeric_alert = false;

function check_AlphaNumericData(obj)
{
  var regexp = /\w/;
  if(!alpha_numeric_alert)
  {
    	for(var i=0;i<obj.value.length;i++)
    	{
        if(!regexp.test(obj.value.charAt(i)))
        {
           	alert("Invalid : "+obj.name);
           	alpha_numeric_alert = true;
           	obj.select();
           	return false;
        }
     }
  }
  else
  {
  	alpha_numeric_alert = false;
  	obj.select();
  	return false;
  }
  return true;
}


function check_CommentData(obj,obj_name)
{
  var regexp = /\w/;

  for(var i=0;i<obj.value.length;i++)
  {
        if(!regexp.test(obj.value.charAt(i)))
        {
           	alert("Invalid : "+obj.name);
           	obj.select();
           	return false;
        }
  }
  return true;
}


function check_AlphaData(obj)
{
   var regexp = /\s/;

    for(var i=0;i<obj.value.length;i++)
    {
        if(!regexp.test(obj.value.charAt(i)))
        {
           alert(obj.name+" : should only be in alphabets");
           //obj.value = "";
           obj.focus();
           return false;
        }
    }
    return true;
}

var starting_letter_alert = false;

function check_StartingLetter(obj)
{
   var regexp = /\d/;
   var regexp1 = /\W/;
   if(!starting_letter_alert)
   {
    if(regexp.test(obj.value.charAt(0)) | regexp1.test(obj.value.charAt(0)))
    {
           alert("Starting letter should only be in alphabet");
           starting_letter_alert = true;
           obj.select();
           return false;
    }
   }
   else
   {
   	starting_letter_alert = false;
        obj.select();
        return false;

   }
    return true;
}


var user_name_alert = false;

function check_UserNameValidation(field)
{
   var flag = true;

   if(!user_name_alert)
   {
   	if(check_StartingLetter(field))
   	{
   		var letters = field.value;

   		for(var i=1;i<letters.length;i++)
   		{
   			if((letters.charAt(i) >= 'A' & letters.charAt(i) <= 'z') | (letters.charAt(i) == '_') | (letters.charAt(i) == '.') | (letters.charAt(i) == '-'))
   			{}
   			else
   			{
   				alert("Invalid : "+field.name);
     				user_name_alert = true;
     				flag = false;
       				field.select();
   				break;
   			}
   		}
   	}
   }
   else
   {
	user_name_alert = false;
	field.select();
	return flag;
   }

   return flag;
}


var role_alert = false;

function check_RoleValidation(field)
{
   var flag = true;

   if(!role_alert)
   {
   	if(check_StartingLetter(field))
   	{
   		var letters = field.value;

   		for(var i=1;i<letters.length;i++)
   		{
   			if((letters.charAt(i) >= 'A' & letters.charAt(i) <= 'z') | (letters.charAt(i) == '_') | (letters.charAt(i) == '.') | (letters.charAt(i) == '-') | (letters.charAt(i) == ' '))
   			{}
   			else
   			{
   				alert("Invalid : "+field.name);
     				role_alert = true;
     				flag = false;
       				field.select();
   				break;
   			}
   		}
   	}
   }
   else
   {
	role_alert = false;
	field.select();
	return flag;
   }

   return flag;
}


var role_alert = false;

function check_NameValidation(field)
{
   var flag = true;

   if(!role_alert)
   {
   	if(check_StartingLetter(field))
   	{
   		var letters = field.value;

   		for(var i=1;i<letters.length;i++)
   		{
   			if((letters.charAt(i) >= 'A' & letters.charAt(i) <= 'z') | (letters.charAt(i) == '_') | (letters.charAt(i) == '.') | (letters.charAt(i) == '-') | (letters.charAt(i) == ' '))
   			{}
   			else
   			{
   				alert("Invalid : "+field.getAttribute("validate"));
				role_alert = true;
				flag = false;
				field.select();
   				break;
   			}
   		}
   	}
   }
   else
   {
	role_alert = false;
	field.select();
	return flag;
   }

   return flag;
}


function checkXmlData(this_object)
{
   	var regexp = /\w/;

	for(var i=0;i<this_object.value.length;i++)
	{
		if(this_object.value.charAt(i) != "" | this_object.value.charAt(i) != " ")
		{
			if(!regexp.test(this_object.value.charAt(i)))
			{
			   	if(i != 0)
			   	{
			   		if(this_object.value.charAt(i) == "-")
			   		{

			   		}
			   		else
			   		{
			   			alert("Special characters or spaces not allowed");
			   			this_object.select();
			   			return false;
					}
				}
				else
				{
					alert("Special characters or spaces not allowed");
					this_object.select();
					return false;
				}
			}
		}
		else
		{
			return false;
		}
	}

    return true;
}

function checkFullEmpty(this_object)
{
	for(var i=0;i<this_object.value.length;i++)
	{
		if(!(this_object.value.charAt(i) == "" | this_object.value.charAt(i) == " "))
		{
			return true;
		}
	}

    return false;
}


function checkEmptyText(this_object)
{
	if(this_object.value != "")
	{
	for(var i=0;i<this_object.value.length;i++)
	{
		if((this_object.value.charAt(i) == "" & this_object.value.charAt(i) == " "))
		{
			this_object.value = "";
			this_object.focus();

			return true;
		}
	}
	}
	else
	{
		this_object.value = "";
		this_object.focus();
		return true;
	}

    return false;
}

function trim(this_object)
{
	var trimmed_value = "";

	prefix_value 	= removeBlanks(this_object.value,0);
	trimmed_value 	= removeBlanks(this_object.value,1);

	return trimmed_value;
}

function removeBlanks(s,mode)
{
	var temp=""
	if(mode == 0)
	{
		for (var i=0; i<s.length; ++i)
		{
			var c=s.charAt(i)
			if (c!=" ") temp += c
		}
	}
	else if(mode == 1)
	{
		for (var i=s.length-1;i>=0;i--)
		{
			var c=s.charAt(i)
			if (c!=" ") temp += c
		}
	}
	return temp
}

